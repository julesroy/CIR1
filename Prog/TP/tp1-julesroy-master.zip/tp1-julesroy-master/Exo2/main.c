﻿// This directive deactivate Warnings for unsecure functions that are deprecated by Microsoft.
// This is not a good practice but is used for pedagogic purposes,
// allowing usage of standard C functions as described in manuals.
// You should use only secured functions named with _s postfix
// e.g. printf_s() rather than printf()
#define _CRT_SECURE_NO_WARNINGS

#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <math.h>
#include <float.h>

/******************************************/
/*   TPC2022 no 1  exo 2                   */
/*                                        */
/******************************************/



int main() {

	// a-
	// 
	// Donnez le code qui permet de calculer la valeur de Pi  en utilisant la relation ArcTang(1) = Pi/4 et le développement limité
	// de la fonction Arctangente :
	//
	// Pi = 4 * ( 1 - 1/3 + 1/5 - 1/7 + 1/9 -1/11 + ... ) 
	// 
	// On arrêtera de calculer les termes de l'addition quand leur valeur sera inférieure à 10e-10
	// Afficher le résultat avec 10 décimales.
	// 

	double val = 1.0, nombre_Pi = 0.0, denominateur = 3.0, signe = -1.0, terme = 0.0, numerateur = 1.0;
	double somme = 1.0;
	while (val > 10E-10)
	{
		val = numerateur / denominateur;
		terme = signe * val;
		signe = -signe;
		denominateur += 2;
		somme = somme + terme;
	}
	nombre_Pi = 4 * somme;
	printf("Pi = %.10lf\n", nombre_Pi);

	// b- 
	// 
	// Affichez la table des sinus des angles allant de 0 à 90 degrés en faisant varier l'angle de 10 degrés en 10 degrés.
	// Quel fichier d'entêtes .h doit-on utiliser ?
	// Définissez la valeur de PI à l'aide d'une constante en lui donnant la valeur 3.1415926535898
	// Afficher la valeur de l'angle en degrés et la valeur du sinus sur la même ligne en alignant les valeurs
	//

	printf("\nOn doit utiliser le fichier d'entete math.h ( fonction sin() )\n\n");

	const double pi = 3.1415926535898;
	printf("Sinus des angles de 0 a 90 degres de 10 en 10:\n");
	int i;
	for (i = 0; i <= 90; i += 10)
	{
		double angle_radian = i * (pi / 180); //conversion de l'angle en degre vers radian
		double val = sin(angle_radian);
		printf("Sinus de %d degres = %f\n", i, val);
	}
	return EXIT_SUCCESS;
}