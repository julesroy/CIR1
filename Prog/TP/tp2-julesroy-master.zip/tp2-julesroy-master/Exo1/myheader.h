#pragma once
#ifndef MYLIB
#define TOTO 1
#endif // !MYLIB

#define MYLIB
