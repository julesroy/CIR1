// This directive deactivates Warnings for unsecure functions that are deprecated by Microsoft.
// This is not a good practice but is used for pedagogic purposes,
// allowing usage of standard C functions as described in manuals.
// You should use only secured functions named with _s postfix
// e.g. printf_s() rather than printf()
#define _CRT_SECURE_NO_WARNINGS

#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <locale.h>
#include <limits.h>
#include <time.h>

/******************************************/
/*   TPC2021 no 2  exo 3				  */
/*                                        */
/******************************************/

int main() {

	setlocale(LC_ALL, "fr-FR");

	int trouve = false; //permet de d�finir le statut de la partie (en cours (false) ou victoire (true))
	int nb_essais = 0;
	int valeur;
	int nbSecret;

	// Seed the random-number generator with the current time so that
	// the numbers will be different every time we run.
	srand((unsigned)time(NULL));


	nbSecret = rand(); //nombre choisi au hasard

	while (trouve == false)
	{
		printf("Entrez un entier\n");
		scanf_s("%d", &valeur);
		if (valeur < nbSecret) {
			printf("Trop petit\n");
			nb_essais++;
		}
		else if (valeur > nbSecret) {
			printf("Trop grand\n");
			nb_essais++;
		}
		else { //dans le cas ou l'on trouve le nombre secret
			trouve = true;
			printf("Victoire\n");
			printf("Score: %d\n", nb_essais);
		}
	}
	
	return(EXIT_SUCCESS);
}