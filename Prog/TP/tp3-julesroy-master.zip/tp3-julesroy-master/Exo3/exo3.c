// This directive deactivates Warnings for unsecure functions that are deprecated by Microsoft.
// This is not a good practice but is used for pedagogic purposes,
// allowing usage of standard C functions as described in manuals.
// You should use only secured functions named with _s postfix
// e.g. printf_s() rather than printf()
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.h>
#include <stdbool.h>


/******************************************/
/*   TPC2022 no 3  exo 3-abc              */
/*                                        */
/******************************************/

#define NBNOTESMAX 30


int main() {
	setlocale(LC_ALL, "fr-FR");

	float val = 0;		// note lue au clavier
	int nbNotes = 0;    // nombre de notes valides
	int nbNotesSaisie = 0; // nombre de notes saisies, on compte aussi les absents
	float total = 0;		 // somme des notes valides
	bool arretSaisie = false; // flag
	int nbAbsences = 0;
	float noteMax = 0;
	float noteMin = 20;
	// 3-a-b-c
	//version sans tableau
	do {
		printf("\nEntrez la note no %d: \n", nbNotesSaisie + 1);
		scanf_s("%f", &val);
		if (val > 20 || val < 0) {
			printf("Absent ou arreter la saisie ? A/O/N\n");
			char rep_utilisateur = _getch(); //on demande a l'utilisateur de saisir une lettre
			if (rep_utilisateur == 'A' || rep_utilisateur == 'a') {
				printf("Absent\n");
				nbAbsences++;
				nbNotesSaisie++;
			}
			else if (rep_utilisateur == 'O' || rep_utilisateur == 'o') {
				arretSaisie = true;
			}
			else if(rep_utilisateur == 'N' || rep_utilisateur == 'n')
			{
				arretSaisie = false;
			}
		}
		else
		{
			nbNotes++;
			nbNotesSaisie++;
			total += val;
			//on v�rifie si la note ajout�e est un extremum
			if (val > noteMax) {
				noteMax = val;
			}
			else if (val < noteMin)
			{
				noteMin = val;
			}
		}
	} while ((nbNotes != NBNOTESMAX) && !arretSaisie );
	
	if (nbNotes != 0) {
		printf("\nLa moyenne de ces %d notes est : %.2f\n", nbNotes, (float)total / (float)nbNotes);
		printf("\nIl y a %d absences.", nbAbsences);
		printf("\nLa plus petite note est %.2f, la plus grande est %.2f", noteMin, noteMax);
	}
	else printf("\nVous n'avez pas saisi de note\n");


	printf("\nBye !\n");
	
	return(EXIT_SUCCESS);
}