// This directive deactivates Warnings for unsecure functions that are deprecated by Microsoft.
// This is not a good practice but is used for pedagogic purposes,
// allowing usage of standard C functions as described in manuals.
// You should use only secured functions named with _s postfix
// e.g. printf_s() rather than printf()
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.h>
#include <math.h>
#include <stdbool.h>
#include <ctype.h>
/******************************************/
/*   TPC2022 no 3  exo 3-d-e-f-g-h        */
/*                                        */
/******************************************/


#define NBNOTESMAX 30

// impl�mentation avec un tableau

//version avec tableau
int main() {
	setlocale(LC_ALL, "fr-FR");

	float val = 0;
	int nbNotes = 0;    // notes valides
	int nbNotesSaisie = 0; // on compte aussi les absents
	float total = 0;		 // somme des notes valides
	bool arretSaisie = 0; // flag
	int nbAbsences = 0;
	float noteMax = 0;
	float noteMin = 20;
	double moyenne = 0;
	//3 - d
	float note[NBNOTESMAX];

	// 3-e
	for (int i = 0; i < NBNOTESMAX; i++)
	{
		note[i] = -2; // on attribue a toutes les cases de note la valeur -2
	}
	// 

	do {
		printf("\nEntrez la note no %d: ", nbNotesSaisie + 1);
		scanf_s("%f", &val);
		if (val > 20 || val < 0) {
			printf("Absent ou arreter la saisie ? A/O/N\n");
			char rep_utilisateur = _getch(); //on demande a l'utilisateur de saisir une lettre
			if (rep_utilisateur == 'A' || rep_utilisateur == 'a') {
				printf("Absent\n");
				nbAbsences++;
				note[nbNotesSaisie] = -1;
				nbNotesSaisie++;
			}
			else if (rep_utilisateur == 'O' || rep_utilisateur == 'o') {
				arretSaisie = true;
			}
			else if (rep_utilisateur == 'N' || rep_utilisateur == 'n')
			{
				arretSaisie = false;
			}
		}
		else
		{
			note[nbNotesSaisie] = val;
			nbNotesSaisie++;
			nbNotes++;
		}
	} while ((nbNotes != NBNOTESMAX) && !arretSaisie );

	if (nbNotes != 0) {
		for (int i = 0; i < NBNOTESMAX; i++) {
			if (note[i] > -1) {
				total += note[i];
				if (note[i] < noteMin)
				{
					noteMin = note[i];
				}
				else if (note[i] > noteMax)
				{
					noteMax = note[i];
				}
			}
		}
		moyenne = (float)total / (float)nbNotes;
		printf("\nLa moyenne de ces %d notes est : %.2f\n", nbNotes, moyenne);
		printf("\nIl y a %d absences.\n", nbAbsences);
		printf("\nLa plus petite note est %.2f, la plus grande est %.2f\n", noteMin, noteMax);
	}
	else {
		printf("\nVous n'avez pas saisi de note\n");
	}

		// 3-f affichage de l'�cart-type 
		double ecartType = 0;
		double sommeEcart = 0;
		for (int i = 0; i < nbNotes; i++) {
			sommeEcart += (note[i] - moyenne) * (note[i] - moyenne);
		}
		sommeEcart = (1.0 / nbNotes) * sommeEcart;
		ecartType += sqrt(sommeEcart);
		
		printf("L'ecart type vaut: %.2f\n", ecartType);

		// 3 - g : affichage du tableau de notes :
		printf("No Note  Valeur note\n");
		int i = 0;
		while ((i < NBNOTESMAX) && (note[i] != -2)) { //si la valeur de la note est -2, on arrete d'afficher les valeurs car il n'y a plus de notes entr�es par l'utilisateur
			printf("%d         %.2f\n", i + 1, note[i]); //i+1 pour que l'affichage de la premiere note soit "Note 1", et non pas "Note 0"
			i++;
		}		
		printf("\n");

		//3 -h - affichage du classement
		int index[NBNOTESMAX];
		float copyNotes[NBNOTESMAX];

		//remplissage des indexs dans le tableau index
		for (int i = 0; i < NBNOTESMAX; i++) {
			index[i] = i;
			//dans ce tableau, les valeurs vont de 0 � 29, pour corriger cela, on fera index[i]+1 pour afficher 1 pour la premiere note
		}

		//cr�ation d'une copie du tableau "note"
		for (int i = 0; i < NBNOTESMAX; i++) {
			copyNotes[i] = note[i];
		}

		//algorithme de tri
		bool status = false; //tant que status est false, cela signifie que le tableau n'est pas tri�
		int permutations_tmp = 0; //variable temporaire de permutation pour le tri
		int cpt_permutations_tri = 0; //compteur de permutations entre valeurs lors d'un tour de boucle
		while (status == false)
		{
			for (int i = 0; i < NBNOTESMAX - 1; i++) {
				if (copyNotes[i] < copyNotes[i + 1]) {
					//permutation entre les 2 valeurs concern�es (principe tri bulle)
					permutations_tmp = copyNotes[i];
					copyNotes[i] = copyNotes[i + 1];
					copyNotes[i + 1] = permutations_tmp;
					cpt_permutations_tri++;
					//permutation entre les indexs, on permute les indexs (dans le tableau index) des valeurs permut�es pr�cedement
					permutations_tmp = index[i];
					index[i] = index[i + 1];
					index[i + 1] = permutations_tmp;
				}
			}
			if (cpt_permutations_tri == 0) {
				//compteur de permutations = 0, donc il n'y a plus rien a trier, status devient true, cela permet de sortir de la boucle while
				status = true;
			}
			//a chaque fin de tour de la boucle while, je r�initialise la valeur du nombre de permutations,
			// ainsi que l'indice i utilis� dans la boucle for
			cpt_permutations_tri = 0;
			i = 0;
		}
		//affichage du tableau tri� une fois le tri termin�
		printf("Rang:   No Note   Valeur note\n");
		int j = 0;
		for (j; j < nbNotes; j++) //on place nbNotes, cela �vite d'avoir les valeurs "-2" affich�es sur l'�cran
		{
			printf("%d        %d          %.2f\n", j+1, index[j]+1, copyNotes[j]); //grands espaces seulement pour mise en forme en console
		}

	printf("\nBye !\n");

	return(EXIT_SUCCESS);
}