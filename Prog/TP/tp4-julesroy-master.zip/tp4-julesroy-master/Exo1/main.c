
// TP4  ************ EXO 1 **************************

#include <stdlib.h>
#include <stdio.h>
#include "tp4.h"

int main() {
	HEURE HeureDebut, HeureFin, Duree;
	HeureDebut.heure = 12;
	HeureDebut.minute = 30;
	
	Duree.heure = 0;
	Duree.minute = 45;

	HeureFin.minute = HeureDebut.minute + Duree.minute; //calcul du nombre de minutes
	HeureFin.heure = HeureDebut.heure + Duree.heure; //calcul du nombre d'heures

	if (HeureFin.minute >= 60) {
		HeureFin.minute -= 60; //si le nombre de minutes est sup�rieur � 60 on le soustrait par 60
		HeureFin.heure++; //et on ajoute 1 au nombre d'heures
	}
	
	printf("%d:%d\n", HeureFin.heure, HeureFin.minute);
	
	return(EXIT_SUCCESS);
}