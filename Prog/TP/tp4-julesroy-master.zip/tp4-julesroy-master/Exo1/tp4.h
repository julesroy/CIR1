#pragma once

typedef struct heure { int heure; int minute; } HEURE;