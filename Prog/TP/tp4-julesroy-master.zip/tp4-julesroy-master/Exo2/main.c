// TP4  ************ EXO 2 **************************
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>


#define SEPARATEUR '/'  
#define TAILLETAB1 20

int main() {
	int MyTab1[TAILLETAB1];
	//on rempli le tableau de 1 � 20
	for (int i = 0; i < TAILLETAB1; i++) {
		MyTab1[i] = i + 1;
	}

	//on affiche le contenu du tableau avec / entre chaque valeur
	for (int j = 0; j < TAILLETAB1; j++) {
		printf("%d %c ", MyTab1[j], SEPARATEUR);
	}
	printf("\n");

	//on affiche le tableau de la fin au d�but � l'aide d'un pointeur
	int pointeur = *(MyTab1 + 19);
	for (int k = 0; k < TAILLETAB1; k++) {
		pointeur = *((MyTab1 + 19) - k); //pour chaque tour de boucle on augmente le pointeur de 19 (pour d�marrer � la fin du tableau), et on soustrait par k
		printf("%d %c ", pointeur, SEPARATEUR);
	}

	return(EXIT_SUCCESS);
}