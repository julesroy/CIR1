// TP4  ************ EXO 3 **************************


#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <stdbool.h>
#include <string.h>

/********************** EXO 3 *****************************/

#define MAXNOM 20
#define MAXPRENOM 20

int main() {
	char nom[MAXNOM];
	char prenom[MAXPRENOM];
	char sexe;

	printf("Nom: ");
	scanf_s("%19s", nom, (unsigned)_countof(nom)); //scanf que l'on enregistre dans le tableau nom
	printf("\n");
	printf("Prenom: ");
	scanf_s("%19s", prenom, (unsigned)_countof(prenom)); //scanf que l'on enregistre dans le tableau prenom

	printf("\nEntrer le sexe : ");
	do {
		sexe = (char)_getch();
	} while ((sexe != 'F') && (sexe != 'H'));

	printf("\n");
	//en fonction de la lettre lue par getch(), on adapte la phrase r�ponse
	if (sexe == 'H') {
		printf("Monsieur %s %s", nom, prenom);
	}
	else {
		printf("Madame %s %s", nom, prenom);
	}

	





	return(EXIT_SUCCESS);
}