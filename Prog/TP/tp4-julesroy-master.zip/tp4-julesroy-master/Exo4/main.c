#define _CRT_SECURE_NO_WARNINGS
// TP4  ************ EXO 4 **************************


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

/********************** EXO 4 *****************************/

#define MAXMOT 256

int main() {
	char mot[MAXMOT] = { '\0' }; //on met \0 pour �viter tout probleme de taille avec strlen()
	char mot_inverse[MAXMOT] = { '\0' }; //on met \0 pour �viter tout probleme de taille avec strlen()

	printf("Entrer le mot dont on souhaite verifier s'il s'agit d'un palindrome ?: ");
	scanf_s("%s", mot, (unsigned)_countof(mot)); //scanf qui enregister dans le tableau mot
	int taille = strlen(mot); //on obtient le nombre de lettre du mot entr� dans le tableau mot

	for (int i = 0; i < taille; i++) { //la valeur obtenue dans int taille nous permet de d�finir la limite de notre boucle for
		//pour chaque tour de boucle, on ajoute a mot inverse une lettre de mot en partant de la fin
		*(mot_inverse + i) = *(mot + taille - 1 - i); //mot + taille - 1 permet d'acc�der � la derniere lettre contenue dans le tableau mot (sans le -1, on sort du tableau)
	}

	//verification
	bool correspond = true;
	int j = 0;
	while (correspond == true && j < taille)
	{
		//on compare les deux tableaux, tant que les lettres correspondent la boucle while continue
		if(mot[j] != mot_inverse[j]){
			correspond = false; //si deux lettre ne correspondent pas, correspond devient faux et donc la boucle while s'arr�te
			printf("%s n'est pas un palindrome\n", mot);
			return(EXIT_SUCCESS);
		}
		j++;
	}
	printf("%s est un palindrome\n", mot);

	return(EXIT_SUCCESS);
}