// TP4  ************ EXO 5 **************************


#include <stdlib.h>
#include <stdio.h>
#include <string.h>


#define MAXPHRASE 1024

int main() {
	char phrase[MAXPHRASE];
	gets_s(phrase, sizeof(phrase));

	//on va parcourir le buffer pour determiner le nombre de mots, ainsi que la longueur moyenne
	int pointeur = *(phrase); //initialisation d'un pointeur sur le premier �l�ment du tableau
	int i = 0; //variable qui permettra de se d�placer dans le tableau
	float compteur_caracteres = 0; //variable qui stockera le nombre de caract�res (servira lors du calcul de la moyenne)
	float compteur_mots = 0; //variable qui stockera le nombre de mots
	while (pointeur != '\0') { //tant que l'on ne rencontre pas le caract�re de fin de cha�ne
		pointeur = *(phrase + i);
		if (pointeur == ' ') {
			compteur_mots++; //si on rencontre un espace, cela signifie que l'on va rencontrer un nouveau nom, donc on incr�mente le compteur de mots
		}
		else {
			compteur_caracteres++; //sinon, on est toujours dans le m�me mot, donc on incr�mente le compteur de caract�res
		}
		i++; //incr�mentation de i, on va donc �tudier la prochaine case du tableau phrase au prochain tour de boucle
	}

	printf("Il y a %.0f mots, soit une longueur moyenne de %.2f caracteres par mot", compteur_mots + 1, ((compteur_caracteres - 1)/(compteur_mots + 1))); //affichage des r�sultats et calcul de la longueur moyenne des mots de la phrase

	return(EXIT_SUCCESS);
}