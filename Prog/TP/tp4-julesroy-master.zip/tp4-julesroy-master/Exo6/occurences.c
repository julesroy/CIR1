// TP4  ************ EXO 6 **************************


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <locale.h>

#define TAILLE 100


// Ecrire un programme qui recherche et affiche toutes les positions d�une valeur donn�e dans un
// tableau de 100 entiers compris entre 0 et 20. Le tableau est initialis� avec des nombres al�atoires.Le
// programme indique s�il n�a pas trouv� la valeur.
// L�affichage se fait comme suit :
// Entrer la valeur recherch�e : 12
// La valeur 12 a �t� trouv�e en 0 puis en 5, puis en 37.
// Contrainte : La recherche se fait � l�aide d�une variable nomm�e Curseur de type pointeur d�entier et
// qui doit :
//  � �tre correctement d�clar�e
//  � �tre initialis�e avec l�adresse du premier �l�ment du tableau
//  � parcourir toutes les positions du tableau afin de comparer l��l�ment point� avec la valeur
//    recherch�e.


int rangedRand(int range_min, int range_max)
{
	// Generate random numbers in the half-closed interval
	// [range_min, range_max). In other words,
	// range_min <= random number < range_max

	int u = (int)((double)rand() / ((double)RAND_MAX + 1) * ((double)range_max - (double)range_min)) + range_min;
	return(u);
}


int main() {
	setlocale(LC_ALL, "fr-FR");
	// Seed the random-number generator with the current time so that
	// the numbers will be different every time we run.
	srand((unsigned)time(NULL));
	int tab[TAILLE];
	
	//remplissage tableau
	for (int i = 0; i < TAILLE; i++) {
		tab[i] = rangedRand(0, 20); //on rempli chaque case du tableau avec un nombre compris entre 0 et 20
		printf("%d, ", tab[i]); //on affiche le tableau (non demand�, mais permet de v�rifier l'exactitude des r�sultats donn�s par la suite du programme)
	}

	int val_recherche = 0;
	printf("Quelle valeur recherchez-vous ?\n");
	scanf_s("%d", &val_recherche);

	int curseur = *(tab); //on initialise le pointeur sur le premier �l�ment du tableau
	int nb_occurence = 0; //le nombre d'occurences permet d'afficher un texte en particulier
	for (int j = 0; j < TAILLE; j++) {
		curseur = *(tab + j); //pour chaque tour de boucle, on passe a la case suivante gr�ce a curseur (pointeur) et � j
		if (curseur == val_recherche) {
			if (nb_occurence == 0) { //on a aucune occurence avant celle-ci, on affiche donc le d�but de la phrase
				printf("La valeur a ete trouve en position %d, ", j);
				nb_occurence++;
			}
			else { //on a d'autres occurences avant celle-ci, on affiche donc la suite de la phrase
				printf("en position %d, ", j);
				nb_occurence++;
			}
		}
	}
	if (nb_occurence == 0)
	{
		printf("\n%d n'etait pas present dans ce tableau\n", val_recherche);
	}

	

	return(EXIT_SUCCESS);
}