#include "gtest/gtest.h"
extern "C" {
#include "../TP 5/tab.h"
}
	
// TP no 5 suivant �nonc� TP5 v23.0
	// test fonctions exo 1 -  partie 1

#define TAB1SIZE 10 // taille du tableau tab1
#define TAB2SIZE 100	// taille du tableau tab 

	int tab1[TAB1SIZE];

	TEST(InitTab_ALL, Alltest) {
		int ret =0;
		for (size_t i = 0; i < TAB1SIZE; i++)
		{
			tab1[i] = 1;
		}

		ret = initTab(tab1, TAB1SIZE);

		ASSERT_EQ(tab1[0], 0);
		ASSERT_EQ(tab1[TAB1SIZE - 1], 0);
		ASSERT_EQ(ret, TAB1SIZE);
		ret = initTab(NULL, TAB1SIZE);
		ASSERT_EQ(ret, -1);
		ret = initTab(tab1, -TAB1SIZE);
		ASSERT_EQ(ret, -1);

	}
	TEST(Display_Array_ALL, Alltest) {
		int ret = 0;
		for (size_t i = 0; i < TAB1SIZE; i++)
		{
			tab1[i] = (int) i+1;
		}

		ret = displayArray(tab1, TAB1SIZE, TAB1SIZE);
		ASSERT_EQ(ret, 0);
		ret = displayArray(NULL, TAB1SIZE, TAB1SIZE);
		ASSERT_EQ(ret, -1);
		ret = displayArray(tab1, TAB1SIZE -1, TAB1SIZE);
		ASSERT_EQ(ret, -1);
	}
	TEST(Realloc_Array, noRealloc) {
		int *ret = NULL;
		int size = TAB2SIZE;
		int eltsCount = 0;
		int* tab = NULL;
		tab = (int*)malloc(TAB2SIZE * sizeof(int));

		ret = addElementToArray(NULL, &size, &eltsCount, 100);
		ASSERT_EQ(ret, nullptr);
		ret = addElementToArray(tab, NULL, &eltsCount, 100);
		ASSERT_EQ(ret, nullptr);
		ret = addElementToArray(tab, &size, NULL, 100);
		ASSERT_EQ(ret, nullptr);
		
		if (tab != NULL) {

			ret = addElementToArray(tab, &size, &eltsCount, 10);
			ASSERT_EQ(ret, tab);
			if (ret != NULL) {
				tab = ret;
				ASSERT_EQ(tab[0], 10);
				ASSERT_EQ(eltsCount, 1);
				ASSERT_EQ(size, TAB2SIZE);
			}
		}
		else {
			ASSERT_TRUE(false);
		}
		int idx = 2;
		while (tab != NULL && idx <= TAB2SIZE) {
			
			ret = addElementToArray(tab, &size, &eltsCount, idx * 10);
			ASSERT_EQ(ret, tab);
			if (ret != NULL) {
				tab = ret;
				ASSERT_EQ(tab[idx-1], idx * 10);
				ASSERT_EQ(eltsCount, idx);
				ASSERT_EQ(size, TAB2SIZE);
			}
			++idx;
		}
		if (tab == NULL) {
			ASSERT_TRUE(false);
		}
		
		free(tab);
		
	}
	TEST(Realloc_Array, Realloc) {
		int* ret = NULL;
		int size = TAB2SIZE;
		int eltsCount = 0;
		int* tab = NULL;
		tab = (int*)malloc(TAB2SIZE * sizeof(int));

		ret = addElementToArray(NULL, &size, &eltsCount, TAB2SIZE);
		ASSERT_EQ(ret, nullptr);
		ret = addElementToArray(tab, NULL, &eltsCount, TAB2SIZE);
		ASSERT_EQ(ret, nullptr);
		ret = addElementToArray(tab, &size, NULL, TAB2SIZE);
		ASSERT_EQ(ret, nullptr);

		if (tab != NULL) {

			ret = addElementToArray(tab, &size, &eltsCount, 10);
			ASSERT_EQ(ret, tab);
			if (ret != NULL) {
				tab = ret;
				ASSERT_EQ(tab[0], 10);
				ASSERT_EQ(eltsCount, 1);
				ASSERT_EQ(size, TAB2SIZE);
			}
		}
		else {
			ASSERT_TRUE(false);
		}
		int idx = 2;
		while (tab != NULL && idx <= TAB2SIZE) {

			ret = addElementToArray(tab, &size, &eltsCount, idx * 10);
			ASSERT_EQ(ret, tab);
			if (ret != NULL) {
				tab = ret;
				ASSERT_EQ(tab[idx - 1], idx * 10);
				ASSERT_EQ(eltsCount, idx);
				ASSERT_EQ(size, TAB2SIZE);
			}
			++idx;
		}
		if (tab == NULL) {
			ASSERT_TRUE(false);
		}
		else { // ajout d'un element en for�ant la r�allocation
			ret = addElementToArray(tab, &size, &eltsCount, idx * 10);

			if (ret != NULL) {
				tab = ret;
				ASSERT_EQ(tab[idx - 1], idx * 10);
				ASSERT_EQ(eltsCount, idx);
				ASSERT_EQ(size, TAB2SIZE + APPENDSIZE);
			}
		}
		free(tab);

	}





