#include "gtest/gtest.h"
extern "C" {
#include "../TP5 Exo 2/array.h"
}



// test fonctions exo 2



TEST(Struct_Array, newArray) {
	
	ARRAY myArray = newArray();
	if (myArray.elt != NULL) {
		ASSERT_EQ(myArray.eltsCount, 0);
		ASSERT_EQ(myArray.size, INITIALSIZE);
		free(myArray.elt);
	}
	else {
		ASSERT_EQ(myArray.size, 0);
		ASSERT_TRUE(false);
	}	
}
TEST(Struct_Array, incrementArraySize) {
	int ret = 0;
	ARRAY myArray = newArray();
	if (myArray.elt != NULL) {
		ASSERT_EQ(myArray.eltsCount, 0);
		ASSERT_EQ(myArray.size, INITIALSIZE);

		ret = incrementArraySize(NULL, APPENDSIZE);
		ASSERT_EQ(ret, -1);
		ret = incrementArraySize(&myArray, 0);
		ASSERT_EQ(ret, -1);
		ret = incrementArraySize(&myArray, APPENDSIZE);
		ASSERT_EQ(ret, myArray.size);
		int trueSize = (int) _msize(myArray.elt) / (int)sizeof(int);
		ASSERT_EQ(myArray.size, trueSize);
		if (myArray.elt != NULL) {
			free(myArray.elt);
		}
		else {
			ASSERT_TRUE(false);
		}
	}
	else {
		ASSERT_TRUE(false);
	}

}

TEST(Struct_Array, setElement) {
	int ret = 0;
	ARRAY myArray = newArray();
	if (myArray.elt != NULL) {
		ASSERT_EQ(myArray.eltsCount, 0);
		ASSERT_EQ(myArray.size, INITIALSIZE);

		ret = setElement(&myArray, 0, 10);
		ASSERT_EQ(ret, 0);
		ret = setElement(NULL, 1, 10);
		ASSERT_EQ(ret, 0);
		ret = setElement(&myArray, 1, 10);
		ASSERT_EQ(ret, 1);

		for (size_t i = 0; i < INITIALSIZE; i++)
		{
			setElement(&myArray, (int)i + 1, (int)i + 1);
		}
		ASSERT_EQ(myArray.elt[0], 1);
		ASSERT_EQ(myArray.elt[INITIALSIZE-1], INITIALSIZE);
		ASSERT_EQ(myArray.eltsCount, INITIALSIZE);

		free(myArray.elt);
	}
	else {
		ASSERT_EQ(myArray.size, 0);
		ASSERT_TRUE(false);
	}

	
}

TEST(Struct_Array, setElementPadding) {
	int ret = 0;
	ARRAY myArray = newArray();
	if (myArray.elt != NULL) {
		ret = setElement(NULL, 1, 1);
		ASSERT_EQ(ret, 0);
		ret = setElement(&myArray, 0, 1);
		ASSERT_EQ(ret, 0);
		int pos = 1;
		int val = 1;
		ret = setElement(&myArray, pos, val);
		ASSERT_EQ(ret, pos);
		ASSERT_EQ(myArray.elt[pos - 1], val);
		pos = INITIALSIZE+3;
		val = 99;
		ret = setElement(&myArray, pos, val);
		ASSERT_EQ(ret, pos);
		ASSERT_EQ(myArray.elt[pos - 1], val);
		ASSERT_EQ(myArray.elt[pos - 2], 0);
		ASSERT_EQ(myArray.elt[pos - 3], 0);
	}
	else {
		ASSERT_TRUE(false);
	}

}
TEST(Struct_Array, deleteElement) {
	int ret = 0;
	int posStart = 0;
	int posEnd = 0;
	ARRAY myArray = newArray();
	if (myArray.elt != NULL) {
		ret = deleteElements(NULL, 1, 1, true);
		ASSERT_EQ(ret, -1);
		posStart = 0;
		posEnd = 0;
		ret = deleteElements(&myArray, posStart, posEnd, true);
		ASSERT_EQ(ret, -1);
		posStart = 1;
		posEnd = myArray.eltsCount+1;
		ret = deleteElements(&myArray, posStart, posEnd, true);
		ASSERT_EQ(ret, -1);
		for (size_t i = 0; i < INITIALSIZE; i++)
		{
			ret = setElement(&myArray, (int)i + 1, (int)i + 1);
		}
		if (INITIALSIZE >= 10) {
			posStart = 5;
			posEnd = 7;
			ret = deleteElements(&myArray, posStart, posEnd, true);
			ASSERT_EQ(myArray.elt[4], 8);
			ASSERT_EQ(myArray.elt[6], 10);
			ASSERT_EQ(myArray.eltsCount, INITIALSIZE - (posEnd - posStart + 1));
		}
		posStart = 1;
		posEnd = myArray.eltsCount + 1;
		ret = deleteElements(&myArray, posStart, posEnd, true);
		ASSERT_EQ(ret, -1);

	}
	else {
		ASSERT_TRUE(false);
	}

}


