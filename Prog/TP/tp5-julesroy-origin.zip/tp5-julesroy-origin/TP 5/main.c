#include <locale.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "tab.h"


#define TAB1SIZE 10 // taille du tableau myTab1
#define TAB2SIZE 100 // taille du tableau myTab2
#define TAB3SIZE 100 // taille du tableau myTab3



// TP no 5 suivant �nonc� TP5 v23.0


int main() {
	setlocale(LC_ALL, "fr-FR"); // gestion des accents dans la console

		
	// Exercice 1

	// partie 1

	// D�clarer un tableau nomm� myTab1 de 10 valeurs de type int.
	// Utiliser la constante de la section #define pour fixer la taille.
	int myTab1[TAB1SIZE]; //d�claration du tableau

	// Tester les fonctions en d�-commentant les lignes suivantes
	int ret= initTab(myTab1, TAB1SIZE);
	ret = displayArray(myTab1, TAB1SIZE, TAB1SIZE);
	
	// Cr�er un tableau myTab2 de mani�re dynamique dans le programme principal.b
	// La taille de ce tableau sera d�abord d�finie � l�aide d�une constante TAB2SIZE qui vaut 100.
	// Tester la fonction d�initialisation � z�ro du tableau myTab2.
	// Remplir les 20 premi�res valeurs du tableau avec les nombres de 1 � 20.
	// Afficher les 20 premi�res valeurs du tableau.
	// D�truire le tableau myTab2.
	int *myTab2 = malloc(TAB2SIZE * sizeof(int));
	int ret2 = initTab(myTab2, TAB2SIZE);
	//remplissage tableau val 1 � 20
	if (myTab2 == NULL) {
		exit(myTab2); //si le pointeur est null, on sort du programme
	}
	else { //sinon, pour les valeurs concern�es, on attribue les valeurs de 1 � 20
		for (int j = 0; j < 20; j++) {
			*(myTab2 + j) = j + 1;
		}
		ret2 = displayArray(myTab2, TAB2SIZE, 20); //on affiche le tableau myTab2
		free(myTab2); //destruction de myTab2 par lib�ration de la m�moire allou�
	}
	// partie 2
	// 
	// Ecrire la fonction addElementToArray qui ajoute un nombre entier � la suite des valeurs d�j� entr�es et 
	// met � jour le nombre d'�l�ments stock�s ainsi que la capacit� r�elle du tableau.
	// Si le tableau est trop petit, il doit �tre agrandi de APPENDSIZE �l�ments.

	int* tmp;
	int i = 1;
	int nbElts = 0; //au d�part, il n'y a pas d'�l�ments dans le tableau (il n'y a que des 0 (initTab))
	//cr�ation du tableau
	int* myTab3 = malloc(TAB3SIZE * sizeof(int));
	int ret3 = initTab(myTab3, TAB3SIZE);
	//ajout des valeurs de 1 � 175
	do {
		tmp = addElementToArray(myTab3, TAB3SIZE, &nbElts, i);
		if (tmp == NULL)
		{
			printf("\n l'ajout de l'�l�ment dans le tableau a �chou�");
		}
		else {
			myTab3 = tmp;
		}
		i++;
		nbElts++; //si l'op�ration a r�ussi, cela signifie qu'il y a un �l�ment de plus dans le tableau
	} while (tmp != NULL && i < 176);

	displayArray(myTab3, TAB3SIZE, nbElts);
	free(myTab3);	
	return(EXIT_SUCCESS);
}