#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <locale.h>
#include "tab.h"

//************************ Exercice 1 ********************************


// Partie  1 : Passage d'un tableau en argument


/// <summary>
/// Fill integers array with zero values
/// </summary>
/// <param name="array">: ref name to array</param>
/// <param name="size">: value of elements count</param>
/// <returns>array is NULL pointer or size parameter is less than 0 return -1. Default returns array size</returns>
int initTab(int* array, int size) {
	for (int i = 0; i < size; i++) {
		*(array + i) = 0;
	}
	return(size);
}
/// <summary>
/// Display a one dimensional array of integers
/// </summary>
/// <param name="array">: ref name to array</param>
/// <param name="size">: value of array size</param>
/// <param name="nbElts">value of elements count</param>
/// <returns>if array is NULL pointer or size is less than 0 or size less than nbElts returns -1, default returns 0</returns>
int displayArray(int* array, int size, int nbElts) {
	for (int i = 0; i < nbElts; i++)
	{
		printf("%d ", *(array + i));
	}
	printf("\n"); //retour a la ligne
	return(0);
}
// Exo 1 : partie 2 : insertion d'un �lement dans un Tableau dynamique avec realloc() 

/// <summary>
/// Append a new element in an array. If array is too small, it will be expanded to size + APPENDSIZE
/// </summary>
/// <param name="array">: ref name to array</param>
/// <param name="size">: ref name to array size</param>
/// <param name="eltsCount">: ref name to elements count</param>
/// <param name="element">: value of element to be appended</param>
/// <returns></returns>
int* addElementToArray(int* array, int* size, int* eltsCount, int element) {
	while (element > size) { //si il y a plus d'�l�ments que de taille totale
		int* new_array; //array dans lequel sera effectu� le realloc
		//realloc avec APPENDSIZE
		new_array = (int*)realloc(array, APPENDSIZE * sizeof(int));
		//en cas d'erreur, on restaure l'array, et on sort du programme
		if (array == NULL) {
			new_array = array;
			return(EXIT_FAILURE);
		}
		else { //sinon
			array = new_array; //on affecte l'array avec l'espace r�allou�
			size += APPENDSIZE; //on augmente la taille
		}
	}
	//on ajoute l'�l�ment
	if (array != NULL) { //si le tableau n'est pas NULL
		*(array + *eltsCount) = element;
	}
	return(array);
	//je remarque une erreur que je n'ai pas su corriger, certaines valeurs sont remplac�es par des adresses
}