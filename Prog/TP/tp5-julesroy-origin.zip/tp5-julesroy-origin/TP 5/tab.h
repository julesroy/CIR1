#pragma once
// TP no 5 suivant �nonc� TP5 v23.0

#define APPENDSIZE 50 // Taille ajout�e lors d'un accroissement de la taille d'un tableau

int initTab(int* array, int size);
int displayArray(int* array, int size, int nbElts);
int* addElementToArray(int* array, int* size, int* eltsCount, int element);