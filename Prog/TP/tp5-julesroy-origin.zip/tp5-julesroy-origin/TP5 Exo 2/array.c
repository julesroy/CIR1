#include <stdlib.h>
#include <stdio.h>
#include <memory.h>
#include "array.h"


/// <summary>
/// Create a new array using ARRAY type
/// </summary>
/// <returns>value struct Array</returns>

ARRAY newArray() {
	ARRAY array;
	array.elt = (int*)malloc(INITIALSIZE * sizeof(int)); //on intialise la tableau par allocation dynamique
	if (array.elt == NULL) {
		array.elt == NULL; //si il y a echec de l'allocation, array.elt est NULL
	}
	array.eltsCount = 0;
	array.size = INITIALSIZE; //la taille de base correspond � 100
	return(array); //on retourne la structure
}

/// <summary>
/// Increase array size by value of incrementValue parameter
/// </summary>
/// <param name="array">ref array</param>
/// <param name="incrementValue">value int count to be added</param>
/// <returns>failed returns -1, ok returns new size</returns>
int incrementArraySize(ARRAY* array, int incrementValue) {
	if (array == NULL) {
		return -1; //en cas d'erreur
	}
	int* new_array;
	new_array = realloc(array->elt, array->size * sizeof(int) + incrementValue * sizeof(int));
	if (new_array == NULL) { //si la r�allocation a �chou�e, on retourne -1
		return -1; //en cas d'erreur
	}
	else {
		array->elt = new_array; //on affecte le tableau agrandi a array->elt
		array->size += incrementValue; //on affecte la nouvelle taille a array->size
		return(array->size); //on retourne la taille du tableau de la structure
	}
}

/// <summary>
/// Write new element at given position with zero padding if
/// position is behind but not immediatly behind the last element.
/// </summary>
/// <param name="array">: ref name to array</param>
/// <param name="pos">: value of position starting from 1</param>
/// <param name="element">: value of element to be inserted</param>
/// <returns>error conditions return 0 success returns element position </returns>
int setElement(ARRAY* array, int pos, int element) {
	while (pos > array->eltsCount) {
		int depart = array->size + 1; //on r�cup�re l'ancien size + 1 pour savoir a partir d'o� on remplace par 0
		incrementArraySize(array, pos - array->size); //agrandissement dynamique du tableau
		for (int i = array->eltsCount; i < pos - 1; i++) {
			*(array->elt + i) = 0; //on se place sur l'�l�ment concern� par l'it�ration avec un pointeur, et on lui assigne la valeur 0
			array->eltsCount = array->eltsCount + 1; //on incr�mente le nombre d'�l�ments dans le tableau
		}
		*(array->elt + pos - 1) = element; //on place l'�l�ment pass� en param�tre dans le tableau
		array->eltsCount = array->eltsCount + 1; //on met � jour le nombre d'�l�ments dans le tableau (incr�mentation)
	}
	return pos; //on retourne la position
}
/// <summary>
/// display part of the array from start to end position
/// </summary>
/// <param name="array">: ref name to array</param>
/// <param name="startPos">: value of start position</param>
/// <param name="endPos">: value of end position</param>
/// <returns>error returns -1, ok return 0</returns>
int displayElements(ARRAY* array, int startPos, int endPos) {
	for (int i = startPos; i < endPos; i++) { //boucle for pour afficher les �l�ments
		printf("%d ", array->elt[i]); //on affiche l'�lement
	}
	return 0;
}

/// <summary>
/// Deletes elements between startPos and endPos in array
/// Updates elements count and reallocate array with new size.
/// </summary>
/// <param name="array">: Ref name to array</param>
/// <param name="startPos">: Value of start position begining with 1</param>
/// <param name="endPos">: Value of end position less or equals to elements count</param>
/// <returns>error returns -1, ok return array size</returns>
int deleteElements(ARRAY* array, int startPos, int endPos, bool compact) {
	if (array == NULL || startPos > endPos || array->size < startPos || array->size < endPos || startPos == endPos || startPos > array->size || endPos > array->eltsCount) { //on v�rifie les cas qui doivent �tre trait�s comme une erreur
		return -1;
	}
	if (compact) { //si compact est true
		for (int i = startPos - 1; i < array->eltsCount; i++) {
			*(array->elt + i) = *(array->elt + i + (endPos - startPos + 1)); //on se place sur l'�l�ment concern� par l'it�ration avec un pointeur, et on le remplace (suppression)
		}
	}
	else { //si compact est false
		for (int j = startPos; j < endPos; j++) {
			*(array->elt + j) = 0; //on remplace par 0 la valeur concern� pour chaque it�ration
		}
	}
	array->eltsCount = array->eltsCount + (startPos - endPos - 1); //on met � jour le nombre d'�l�ments dans le tableau
	return array->size; //on retourne la taille de l'array
}