#pragma once

#include <stdbool.h>

#define INITIALSIZE 100
#define APPENDSIZE 5

typedef struct Array {

    int *elt; // le tableau d�entiers
    int size;  // la taille de ce tableau d�entiers
    int eltsCount; // le nombre d��l�ments dans le tableau

} ARRAY;


ARRAY newArray();

int incrementArraySize(ARRAY* array, int incrementValue);

int setElement(ARRAY* array, int pos, int element);

int displayElements(ARRAY* array, int startPos, int endPos);

int deleteElements(ARRAY* array, int startPos, int endPos, bool compact);