#include <locale.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "array.h"


// Correction TP no 5 suivant �nnonc� TP5 v23.0

//************************ Partie 2 ********************************

int main() {
	setlocale(LC_ALL, "fr-FR"); // gestion des accents dans la console

	ARRAY myTab;
	myTab = newArray();
	for (int i = 1; i <= 100; i++) {
		setElement(&myTab, i, i);
	}
	setElement(&myTab, 101, 101);
	setElement(&myTab, 110, 110);
	printf("Affichage de myTab (avec les reallocations:\n");
	displayElements(&myTab, 0, myTab.eltsCount);
	deleteElements(&myTab, 50, 60, true);
	printf("\n\nSuppresion des valeurs entre 50 et 60 :\n");
	displayElements(&myTab, 0, myTab.eltsCount);
	printf("\n\nOn remarque que les valeurs comprises entre 50 (inclus) et 60 (inclus) ont etes supprimees\n");
	return(EXIT_SUCCESS);
}