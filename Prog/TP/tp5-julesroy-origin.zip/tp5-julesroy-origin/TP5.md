# TP C no 5 v23.0

# Les Fonctions – L'allocation Dynamique de mémoire

```ad-tip
title: Attention
Ce TP utilise les tests unitaires Google Tests.
Les projets Eval-Exo1 et Eval-Exo2 sont des projets de tests et ne doivent pas être modifiés, sauf si on vous le demande. Ils servent à valider le bon fonctionnement de vos fonctions.

Le projet doit être cloné dans un répertoire proche de la racine afin ne pas créer des chemins trop longs pour les fichiers du paquetage de test.

Après avoir cloné la solution TP5, si le Package NuGet de test ne fonctionne pas, il faut faire un clic-droit sur le nom de la solution dans l'explorateur de solution et choisir l'option 'Restaurer les Packages NuGet' ou utiliser le gestionnaire de packages NuGet pour mettre à jour les packages NuGet dans la dernière version stable pour la solution. Il faut parfois désintaller puis ré-installer le package NuGet.

```



```ad-info
title: Rappel
collapse: open

En langage C, une fonction est un sous-programme qu'on appelle depuis la fonction main() ou depuis une autre fonction. Le langage fournit ses propres fonctions comme 'printf()' et il est possible d'en écrire d'autres afin de bâtir un programme de manière structurée.

Une fonctions se met en place dans trois contextes différents :
  
* La déclaration à l'aide d'un prototype, annonce l'existence de la fonction et comment on communique avec elle.
* L'implémentation ou corps de la fonction, fournit le code qui décrit le traitement à réaliser. 
* L'appel de fonction, est l'utilisation effective d'une fonction depuis une autre fonction.

Caractéristiques principales d'une fonction :
  
* Elle porte un nom sensible à la casse (ex : MyFunction() )  
* Elle reçoit des arguments, quand on l'appelle, de manière conforme (en nombre et en type) à la liste des paramètres qui ont été définis lors de sa déclaration.  
* Une fonction renvoie une valeur d'un certain type  
* Une fonction qui ne renvoie pas de valeur est déclarée avec le type 'void'  
* Les variables déclarées dans la fonction sont dites 'locales' à la fonction et ne sont pas visibles à l'extérieur de celle-ci.  
* Les variables déclarées à l'extérieur de la fonction principale 'main()' sont dites 'globales'  
* Les variables locales n'existent que le temps de l'exécution de la fonction, sauf si elles sont déclarées 'static' et dans ce cas conservent leur valeur entre les différents appels.  
* Les fonctions reçoivent leurs arguments soit par 'valeur' soit par 'adresse', seul le passage par adresse permet de modifier la valeur, dans la fonction appelante, des variables passées en argument.

```

## Exemple de fonction :


```c
//      Déclaration : 
float Volume( float, float, float);  
//      Implémentation :               
int volume( float hauteur, float largeur, float profondeur) {  
	float resultat = -1;  
	if ((hauteur > 0) && (largeur > 0) && (profondeur > 0)) 
		{  
		resultat = hauteur * largeur * profondeur ;  
		}  
	return( resultat);  
}  
//      Appel :  
vol = volume( 10, 20, 5.5 );
```

## Exercice 1 :

* Déclarez les prototypes des fonctions dans un fichier **tab.h**
* Les fonctions sont implémentées dans le fichier **tab.c.**
  Elles prévoient la réception d'arguments erronés et renvoient un code d'erreur. Par défaut le code vaut 0, il peut être négatif ou NULL s’il y a une erreur, ou, positif pour un code de retour spécifique précisé dans l'énoncé de l’exercice le cas échéant.

* Les fonctions doivent respecter les prototypes proposés.
* Les fonctions sont documentées à l'aide de commentaires simples et pertinents.
* Le programme doit compiler sans erreur et sans warning.


1. **Fonction avec passage d'un tableau en argument**

Il est contraignant de passer un tableau par valeur. Cela revient à recopier le tableau de valeurs sur la pile (Stack) avant l'appel de la fonction, avec les problèmes de performance et de consommation de mémoire que cela induit. Les langages utilisent donc un passage par adresse des tableaux, quitte à interdire l'écriture dans le tableau. En langage C, on passe simplement le nom du tableau, celui-ci étant un pointeur sur le premier élément, on passe donc la valeur de l'adresse de ce premier élément.

Les chaînes de caractères sont implémentées à l'aide de tableaux de caractères, on les manipule de la même manière, ce sont des pointeurs.

* Déclarer un tableau nommé **myTab1** de 10 valeurs de type **int** dans la fonction **main**(). **myTab1** est un tableau de taille fixe.
* Ecrire une fonction qui remplit d’entiers un tableau nommé **tab** de taille **size** avec des zéros.

```c
int initTab( int* tab, int size);
// Valeur de retour : -1 si tab est un pointeur nul ou quand size est négatif, sinon renvoie la taille du tableau.
```

* Ecrire une fonction qui affiche les **nbElts** premiers éléments du tableau **tab** sur une ligne de la console.

```c
int displayArray(int* tab, int size, int nbElts)  
  
Valeur de retour : -1 si tab est un pointeur **NULL** ou size <0 ou size < nbElts, 0 sinon.
```


Plutôt que d'être déclaré avec une taille fixe au moment de la compilation, un tableau peut être dimensionné de façon dynamique au moment de l'exécution du programme. On demande au système de nous fournir un pointeur sur un nouvel espace réservé de mémoire ayant la taille souhaitée. Si le système accepte d'allouer la mémoire demandée, il faut aussi penser à restituer cette mémoire quand toutes les fonctions n'en ont plus besoin.  
  
Exemple de déclaration et d’utilisation un tableau dynamique en trois étapes :

a. Définition des constantes utiles :
```c
#define INITIALSIZE 100 // Taille initiale d'un tableau
#define APPENDSIZE 50 // Taille ajoutée lors d'un accroissement de la taille d'un tableau
```

b. Déclaration du pointeur et des variables qui mémorisent la taille du tableau  
et le nombre de valeurs qui y sont rangées :  
```c
int *myTab2 = NULL;  
int tabSize = INITIALSIZE;  
int nbElts = 0;
```

c. Allocation de la mémoire utilisée par le tableau dynamique :
```c
myTab2 = (int *) malloc( INITIALSIZE * sizeof(int) );  
if ( myTab2 != NULL) 
	{
	// l'allocation a réussi, on peut utiliser le tableau 
	initTab( myTab2, tabSize); 
	}  
else 
	{
	// l'allocation a échoué, il ne faut pas utiliser le tableau
	printf("mémoire insuffisante");
	return(-1); 
	}
```
Pour restituer au système la mémoire **devenue inutile** parce que le programme a fini de s'en servir, on utilise cette fonction de libération :

```c
free(myTab2);
```


* Créez un tableau **myTab2** de manière dynamique dans le programme principal.
* La taille de ce tableau sera d’abord définie à l’aide d’une constante **TAB2SIZE** qui vaut 100.
* Testez la fonction d’initialisation à zéro du tableau **myTab2**.
* Remplissez les 20 premières valeurs du tableau avec les nombres de 1 à 20.
* Affichez les 20 premières valeurs du tableau.
* Détruisez le tableau myTab2.

2. **Agrandissement d'un tableau alloué dynamiquement**

La fonction **realloc**() permet à partir d'un pointeur déjà alloué et d'une nouvelle taille de modifier une zone de mémoire utilisée par un tableau dynamique, donc d'agrandir le tableau sans perdre son contenu.

Nous allons écrire une fonction qui permet d'ajouter un élément à la suite dans le tableau. Si le tableau est rempli, il faut l'agrandir. Les opérations d'allocation sont coûteuses en temps CPU, il faut donc anticiper la demande et allouer suffisamment de place pour éviter de le faire à chaque nouvel ajout.

La fonction **realloc**() va fournir un nouveau pointeur sur une zone plus grande. La fonction d'ajout doit retourner le pointeur qui correspond à la nouvelle position du tableau, ou la valeur NULL lorsque l’agrandissement échoue.

* Ecrire la fonction addElementToArray

```c
int * addElementToArray( int* tab, int* size, int* eltsCount, int element);
```

Elle ajoute un nombre entier à la suite des valeurs déjà entrées et met à jour le nombre d'éléments stockés ainsi que la capacité réelle du tableau. Si le tableau est trop petit, il doit être agrandi de APPENDSIZE éléments.  
  
Valeur de retour :
	NULL : ajout impossible
	différent de NULL : pointeur vers le tableau d’éléments

## Exercice 2 :

Il s’agit d’améliorer la gestion des tableaux en créant une sorte d’objet tableau à l’aide d’une structure. Le tableau d’entiers est en fait un des champs de la structure ARRAY et il est facile de le créer et d’en modifier la taille par des allocations dynamiques.

Créez un type structuré nommé ARRAY pour manipuler les tableaux d'entiers :

```c
typedef struct Array{

       int *elt; // le tableau d’entiers
       int size;  // la taille de ce tableau d’entiers
       int eltsCount; // le nombre d’éléments dans le tableau

} ARRAY;
```

Définissez la constante suivante pour fixer la taille initiale du tableau d’entiers :  
```c
#define INITIALSIZE 100
```

Ecrire les fonctions suivantes qui :

1- Crée un nouveau TABLEAU en allouant une taille initiale pour les données :
```c
/// Renvoie une structure ARRAY, avec le pointeur elt égal à NULL si l'allocation a échoué.
ARRAY newArray( );
```

Le tableau **elt** sera initialisé avec des zéros et le champ **eltsCount** initialisé à zéro.
La taille initiale du tableau **elt** est égale à INITIALSIZE.

2- Modifie la taille du tableau :

```c
// Agrandissement du tableau array de 'incrementValue' élements supplémentaires.
// Renvoie -1 quand l'agrandissement échoue, ou, la nouvelle taille quand cela fonctionnne.
int incrementArraySize(ARRAY* array , int incrementValue);
```

3- Ecrit un élément à une position donnée sans insertion

```c
// renvoie 0 si erreur, sinon position de l’élément inséré
int setElement(ARRAY* array, int pos, int element );
```

Le paramètre **pos** indique la position d’insertion, la première valeur est en position 1.

Si l'élément à écrire n'est pas immédiatement après le dernier élément, il faut agrandir le tableau, et créer des éléments à zéros entre les deux.

4- Affiche une portion du tableau de la position début à la position fin

```c
// renvoie -1 si erreur, sinon 0
// startPos >= EndPos n’est pas un cas d’erreur et doit être traité.
int displayElements(ARRAY* array, int startPos, int endPos );
```

5 - Supprime les éléments à partir de la position début jusqu'à la position fin avec compactage du tableau quand le paramètre 'compact' est vrai.

```c
// Renvoie -1  si erreur, sinon la nouvelle taille du tableau.
// startPos >= endPos n’est pas un cas d’erreur et doit être traité.
// endPos ou startPos ne peuvent pas être supérieurs au nombre d'éléments stockés dans le tableau.
// Si le paramètre compact est égal à vrai, la taille du tableau est ramenée à celle qui permet de stocker le nombre d'éléments restants, sinon on ne modifie pas la taille du tableau.
int deleteElements(ARRAY* array, int startPos, int endPos, bool compact );
```

La fonction met à jour le nombre d'éléments dans le tableau et diminue la taille du tableau par une réallocation lorsqu'on demande un compactage.

6- Déclarez un tableau de type ARRAY dans la fonction main et testez les fonctions
