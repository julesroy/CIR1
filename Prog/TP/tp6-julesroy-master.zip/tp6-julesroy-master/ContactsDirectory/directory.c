/**********************************************************************/
/*****                    R�pertoire t�l�phonique                   ***/
/**********************************************************************/
/*                                                                    */
/*       rep.c                                                        */
/*       VERSION 23.0                                                 */
/*       Template                                                     */
/*                                                                    */
/*                                                                    */
/**********************************************************************/
/* REMARQUE: le fichier de donn�es est au format suivant :            */
/*      nom;prenom;no_de_telephone1                                   */
/*      nom2;prenom2;no_de_telephone2                                 */
/*      ...                                                           */
/* soit un enregistrement par ligne de 3 champs separ�s par ';'        */
/* Si on utilise un autre fichier de donnees que data.csv, il faut     */
/* passer son nom en param�tre � l'appel du programme                 */
/**********************************************************************/

#include <stdio.h>   /* pour les entr�es-sorties */
#include <string.h>  /* pour les manipulations de cha�nes de caract�res */
#include <conio.h>
#include <ctype.h>
#include <stdlib.h>
#include <locale.h>
#include <stdbool.h>
#include <fcntl.h>
#include "directory.h"
#include "ConsoleTools.h"




/*****************************************************************************/
/*                        main program                                       */
/*****************************************************************************/

int main(int argc, char *argv[])
{

	int selectAction;						/* selected option in user interface menu */
	currentLanguage = En;

	Directory repertoire;			/* declare the directory in memory */
	
	
	system("CHCP 1252");			/* Codepage selecion for accentued characters support */
	printf("\nsetlocale : %s\n", setlocale(LC_ALL, "fr-FR"));

	openConsole();
	
	consoleSize = getConsoleSize();
	setWriteColor(BRIGHTYELLOW);
	setBackGroundColor(BRIGHTBLUE);
	clearScreen();

	if (argc == 1)
	{
		strcpy_s((char*)nom_fichier, _countof(nom_fichier), "data.csv");	/* default file name for Directory datas saving */
	}
	else
	{
		strcpy_s((char *)nom_fichier, _countof(nom_fichier), (char *)argv[1]);	/* alternate user filename for Directory file */
	}
	// Directory is not modified yet
	modif = false;
	// initialize contacts count to zero and allocates memory for Directory defined storage capacity
	// load and sort file
	if (init_rep(&repertoire) <0) return;

	afficher_menu_principal();

	do								/* main menu */
	{							
		int tabOptions[5] = { 31, 7, 8, 9, 10 }; // Options are linked to text message numbers
		selectAction = selectChoice(mess[11], 5, tabOptions);

		switch (selectAction)
		{
		case 31: 
			select_lang();
			break;
		case 7:
			affichage_repertoire(&repertoire);
			break;
		case 8:
			option_ajouter(&repertoire);
			break;
		case 9:
			option_rechercher(&repertoire);
			break;
		}
		afficher_menu_principal();
	} while (selectAction != 10);

	// if directory was modified, suggest to save it

	if (modif)					
	{						
		int tabOptions[2] = { 4,6 };
		selectAction = selectChoice(mess[3], 2, tabOptions);


		if (selectAction == 4) // yes, Save
		{
			
			char buffer[MESSAGEBUFFERMAXSIZE] = { 0 };
			// save as default file name ?
			sprintf_s(buffer, _countof(buffer), mess[17], nom_fichier);
			selectAction = selectChoice(buffer, 2, tabOptions);

			// no, enter new file name
			if (selectAction == 6) saisir_chemin(mess[18], nom_fichier);

			// effective saving
			sauvegarder(&repertoire, nom_fichier);
		}
	}
	

	printf(CSI "K");
	printf(CSI "0m");		// Restore previous writing color.
	clearScreen();
	closeConsole();
	return EXIT_SUCCESS;
}
/*****************************FIN du programme principal*********************/





/**********************************************************************/
/* Affichage du menu principal                                        */
/**********************************************************************/

void afficher_menu_principal()
{
	clearScreen();
	moveCursor(1, consoleSize.Y - 20);
	printf("\n\n %s :", mess[12]);
	printf("\n\n\t%s", mess[13]);
	printf("\n\t%s", mess[14]);
	printf("\n\t%s", mess[15]);
	printf("\n\t%s", mess[30]);
	printf("\n\n\t\t%s\n", mess[16]);
}

/**********************************************************************/


