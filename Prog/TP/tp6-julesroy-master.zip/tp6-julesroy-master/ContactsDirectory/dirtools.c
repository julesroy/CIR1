#include <stdio.h>   /* pour les entr�es-sorties */
#include <string.h>  /* pour les manipulations de cha�nes de caract�res */
#include <conio.h>
#include <ctype.h>
#include <stdlib.h>
#include <locale.h>
#include "directory.h"
#include "ConsoleTools.h"

#define VERSION 23.0

/**************************************************************************/
/* Please, fill informations  ->                                          */
/*   Last Name :  ROY                      First Name  :  Jules                 */
/**************************************************************************/

extern bool modif;



/// <summary>
/// Ajout d'un contact dans le r�pertoire stock� en m�moire
/// </summary>
/// <param name="dir">: by Ref : le repertoire</param>
/// <param name="rec">: by Value : le contact</param>
/// <returns>ERROR si �chec ou OK si ajout r�alis�</returns>
int ajouter_un_contact_dans_rep(Directory *dir, Record rec)
{
	int retCode = ERROR;

#ifdef IMPL_TAB
	// D�but ajout Code ici
	if (dir == NULL || dir->elts_count >= MAX_RECORDS) {
		return retCode;
	}
	else {
		dir->tab[dir->elts_count] = rec; //on ajoute le contact dans le tableau
		dir->elts_count += 1; //on incremente le nombre de contacts
		dir->sorted = false; //on met le tableau a false car il n'est plus trie
		retCode = OK;
	}
	modif = true; //on met modif a true car on a modifie le tableau
	return retCode; //on retourne retCode
	// Fin ajout Code ici
#else
#ifdef IMPL_LIST

	int ret = AddNewElementInSortedList(dir->list, &rec, est_sup);
	if (ret == 1) {
		dir->elts_count += 1;
		modif = true;
		retCode = OK;
	}

#endif
#endif

	return(retCode);

}


#ifdef IMPL_TAB

/// <summary>
/// Remove a record from Contacts Directory Array version
/// </summary>
/// <param name="dir">: by Ref : Directory</param>
/// <param name="index">: index of record starting from 0</param>
void supprimer_un_contact_dans_rep(Directory *dir, int index) {
	// Pensez � mettre modif � true quand cela est utile.
	// ajouter code ici pour tableau
	if (dir->elts_count >= 1) { // s'il y a au moins un element dans le tableau 				
		for (int i = index; i < dir->elts_count - 1; i++) {
			dir->tab[i] = dir->tab[i + 1]; //on decale les elements du tableau
		}
		dir->elts_count--; //on decremente le nombre d'elements du tableau
		modif = true; //on met modif a true car on a modifie le tableau
	}
	// Fin ajout Code ici
	return;
}

#else
#ifdef IMPL_LIST
  
	/// <summary>
    /// Remove a record from Contacts Directory Linked List version
	/// </summary>
	/// <param name="dir">: Ref vers un r�pertoire</param>
	/// <param name="elem">: Ref vers un maillon de liste chain�e</param>
	/// <returns>0 si pas de suppression effectu�e ou 1 si une suppression r�alis�e</returns>
int supprimer_un_contact_dans_rep_liste(Directory* dir, SingleLinkedListElem* elem) {

	// D�but ajout Code ici
	DeleteLinkedListElem(dir->list, elem);
	dir->elts_count--;
	modif = true;
	return OK;
	// Fin ajout de code

	return (0);
}
#endif
#endif


/// <summary>
/// Affichage d'un enregistrement sur une ligne � l'�cran
/// </summary>
/// <param name="rec"> : Contact � afficher</param>
void affichage_enreg(Record enr)
{
	// ex Dupont, Jean                 0320304050

	printf("\n%30s,%30s,%20s", enr.nom, enr.prenom, enr.tel);

}
 

/// <summary>
/// Affichage d'un enregistrement avec alignement des mots
/// lors d'un affichage sous la forme d'une liste
/// </summary>
/// <param name="rec"> : Contact � afficher</param>
void affichage_enreg_frmt(Record enr)
{
	// e.g. | Dupont          |Jean             |03 20 30 40 50    |    


	printf(CSI "K");		// Clear the line
	printVerticalBorder();
	printf("%s\t", enr.nom);
	printVerticalBorder();
	printf("%s\t", enr.prenom);
	printVerticalBorder();
	printf("%s\t", enr.tel);
	printVerticalBorder();

}


/// <summary>
/// Evaluates, if in the Ascending Alphabetical Order a Record is After an Other One.
/// </summary>
/// <param name="enr1">: Contact 1</param>
/// <param name="enr2">: Contact 2</param>
/// <returns>true if enr1 is after enr2</returns>
bool est_sup(Record enr1, Record enr2)
{
	// that requires a comparison function pointer in order to insert a value in the list
	// Please, use _stricmp to compare string !
	
	// D�but ajout Code ici
	if (_stricmp(enr1.nom, enr2.nom) > 0) {
		return true; 
	}
	if (_stricmp(enr1.nom, enr2.nom) == 0) {
		if (_stricmp(enr1.prenom, enr2.prenom) > 0) {
			return true;
		}
		if (_stricmp(enr1.prenom, enr2.prenom) == 0) {
			if (_stricmp(enr1.tel, enr2.tel) > 0) {
				return true;
			}
		}
	}
	// Fin ajout code
	return(false);
	
}
 
/*********************************************************************/
/*   Tri Alphabetique du tableau d'enregistrements                   */
/*********************************************************************/

/// <summary>
/// Sort Records Tab in Directory
/// </summary>
/// <param name="dir"></param>
void trier(Directory *dir)
{

#ifdef IMPL_TAB

	// D�but ajout Code ici
	Record temp;
	int tour = 0;
	if (!dir->elts_count) {
		return;
	}
	do {
		tour = 0; // Si tour est toujours � 0 a la fin de la boucle for, le repertoire est tri�
		for (int i = 0; i < dir->elts_count - 1; i++) {// Pour chaque element du repertoire,
			if (est_sup(*(dir->tab + i), *(dir->tab + i + 1))) {//on test si il y'a besoin d'inverser, si oui
				temp = *(dir->tab + i); //on inverse
				*(dir->tab + i) = *(dir->tab + (i + 1));
				*(dir->tab + (i + 1)) = temp;
				tour++; //et a chaque modification on implemente
			}
		}
	} while (tour != 0); //Si tour != 0 On continue
	// Fin ajout Code ici
#else
#ifdef IMPL_LIST
	
	// rien � faire !
	// la liste est toujours tri�e
#endif
#endif

	dir->sorted = true; // le repertoire est tri�

}


/// <summary>
/// Looks for the Next Record with a Matching Name, starting from ind Index.
/// </summary>
/// <param name="dir">: by Ref: the Directory</param>
/// <param name="nom">: Search Name</param>
/// <param name="ind">: Starting search index</param>
/// <returns>The Index of Found Record or -1 if not Found.</returns>
int rechercher_nom(Directory *dir, unsigned char * nom, int ind)
{
	int i = ind; //position (indice) de d�but de recherche dans tableau/liste dir
	
	char tmp_nom[MAX_LASTNAME];
	char tmp_nom2[MAX_LASTNAME];
								
	bool trouve = false;		


#ifdef IMPL_TAB
	// D�but ajout Code ici
	int ind_fin; //position (indice) de fin de tableau/liste dir
	ind_fin = dir->elts_count - 1; //on met ind_fin � la fin du tableau
	strcpy_s(tmp_nom, _countof(tmp_nom), nom); //on copie le nom dans tmp_nom
	_strupr_s(tmp_nom, _countof(tmp_nom)); //on met tmp_nom en majuscule

	while ((i <= ind_fin) && (!trouve)) {
		strcpy_s(tmp_nom2, _countof(tmp_nom2), dir->tab[i].nom); //on copie le nom dans tmp_nom2
		_strupr_s(tmp_nom2, _countof(tmp_nom2)); //on met tmp_nom2 en majuscule
		if (strcmp(tmp_nom, tmp_nom2) == 0) //on compare les deux noms
			trouve = true; //si on trouve, on sort de la boucle
		else
			i++; //sinon on continue
	}
	// Fin ajout Code ici
#else
#ifdef IMPL_LIST
							
	// on se place sur l'�l�ment en i�me position s'il existe

	SingleLinkedListElem *currentElement = GetElementAt(dir->list, i);
	
	// conversion du nom recherch� en majuscule pour faciliter la comparaison
	strcpy_s(tmp_nom, _countof(tmp_nom), (const char*)nom);
	_strupr_s(tmp_nom, _countof(tmp_nom));

	while ((currentElement != NULL) && (!trouve)) {
		strcpy_s(tmp_nom2, _countof(tmp_nom2), (const char*) currentElement->pers.nom);
		_strupr_s(tmp_nom2, _countof(tmp_nom2));
		if (strcmp(tmp_nom, tmp_nom2) == 0)
			trouve = true;
		else {
			// si pas trouv�, on passe au suivant
			currentElement = currentElement->next;
			i++;
		}
	}
#endif
#endif

	return((trouve) ? i : -1);
} 

/// <summary>
/// Remove All Non Digital Char From String.
/// </summary>
/// <param name="s">: pointer to mutable string</param>
void compact(char *s)
{
	// D�but ajout Code ici
	int i = 0;
	int j = 0;

	while (s[i] != 0) {
		if ((s[i] >= '0') && (s[i] <= '9')) { //si compris entre 0 et 9 alors on recopie 
			s[j] = s[i]; //on recopie
			j++;
		}
		i++;
	}
	s[j] = 0; // nouvelle fin de chaine 

	// Fin ajout Code ici
	return;
}

/**********************************************************************/
/* sauvegarde le r�pertoire dans le fichier dont le nom est pass� en  */
/* argument                                                           */
/* retourne OK si la sauvegarde a fonctionn� ou ERROR sinon           */
/**********************************************************************/
int sauvegarder(Directory *dir, unsigned char *file_name)
{
	FILE* fic_rep; //pointeur sur fichier
#ifdef IMPL_TAB
	// D�but ajout Code ici
	int i = 0;
	fopen_s(&fic_rep, file_name, "w+t"); //ouverture du fichier en �criture
	if (fic_rep == 0) return ERROR; //en cas d'erreur
	while (i < dir->elts_count) { //on affiche les elements
		fprintf(fic_rep, "%s", dir->tab[i].nom);
		fprintf(fic_rep, ";");
		fprintf(fic_rep, "%s", dir->tab[i].prenom);
		fprintf(fic_rep, ";");
		fprintf(fic_rep, "%s", dir->tab[i].tel);
		fprintf(fic_rep, "\n");
		i++;
	}
	fclose(fic_rep);
	// Fin ajout Code ici
#else
#ifdef IMPL_LIST
	// Ajouter code entre les balises d�but et Fin - ne pas supprimer les balises
	// @Debut ajout code
	errno_t err = fopen_s(&fic_rep, file_name, "w+t"); //ouverture du fichier en �criture
	if (err == 1 || fic_rep == NULL) return ERROR;
	SingleLinkedListElem* current = GetElementAt(dir->list, 0); //on se place sur le premier element
	while (current != NULL) { //on affiche les elements
		fprintf(fic_rep, "%s;", current->pers.nom);
		fprintf(fic_rep, "%s;", current->pers.prenom);
		fprintf(fic_rep, "%s\n", current->pers.tel);
		current = current->next; //on passe au suivant
	}

	err = fclose(fic_rep); //fermeture du fichier
	if (err) return ERROR;
	//Fin ajout de code
#endif
#endif

	return(OK);

}


  /**********************************************************************/
  /*   charge dans le r�pertoire le contenu du fichier dont le nom est  */
  /*   pass� en argument                                                */
  /*   retourne OK si le chargement a fonctionn� et ERROR sinon         */
  /**********************************************************************/

int charger(Directory *dir, unsigned char *nom_fichier)
{
	FILE *fic_rep;
	errno_t err;
	int num_rec = 0; //num�ro de l'enregistrement
	int long_max_rec = sizeof(Record); //longueur max d'un enregistrement
	unsigned char buffer[sizeof(Record) + 1]; //buffer pour stocker les enregistrements
	int idx = 0; //indice de parcours du buffer

	char *char_nw_line;
	
	_set_errno(0);
	if (((err = fopen_s(&fic_rep, (const char*)nom_fichier, "r")) != 0) || (fic_rep == NULL))
	{
		return(err);
	}
	else
	{
		while (!feof(fic_rep) && (dir->elts_count < MAX_RECORDS))
		{
			if (fgets((char *)buffer, long_max_rec, fic_rep) != NULL)
			{
				//memorisation de l'enregistrement dans le tableau
				buffer[long_max_rec] = 0; //on ajoute le caract�re de fin de chaine

				if ((char_nw_line = strchr((char*)buffer, '\n')) != NULL)
					*char_nw_line = '\0'; //suppression du fin_de_ligne eventuel

				idx = 0;
#ifdef IMPL_TAB
				if (parse_next_field_in_line_char_buffer(buffer, &idx, dir->tab[num_rec].nom, MAX_LASTNAME, SEPARATOR) == OK)
				{
					idx++;
					if (parse_next_field_in_line_char_buffer(buffer, &idx, dir->tab[num_rec].prenom, MAX_LASTNAME, SEPARATOR) == OK)
					{
						idx++;
						if (parse_next_field_in_line_char_buffer(buffer, &idx, dir->tab[num_rec].tel, MAX_TEL, SEPARATOR) == OK)
							num_rec++;
					}
				}
#else
#ifdef IMPL_LIST
				//D�but ajout code
				Record tmp;
				if (parse_next_field_in_line_char_buffer(buffer, &idx, tmp.nom, MAX_LASTNAME, SEPARATOR) == OK)
				{
					idx++;                            // On saute le s�parateur. 
					if (parse_next_field_in_line_char_buffer(buffer, &idx, tmp.prenom, MAX_LASTNAME, SEPARATOR) == OK)
					{
						idx++;
						if (parse_next_field_in_line_char_buffer(buffer, &idx, tmp.tel, MAX_TEL, SEPARATOR) == OK) // Si l'�l�ment est correct.
							num_rec++; // On comptabilise l'�l�ment.
					}
				}
				AppendNewRecordToLinkedList(dir->list, tmp); // On ajoute le record � la liste.
				//Fin ajout code
#endif
#endif
			}

		}
		dir->elts_count = num_rec;
		fclose(fic_rep);
		return(OK);
	}
}

/********************************************************************************/
/* initialisation d'un r�pertoire                                               */
/* prend en param�tre un pointeur vers le r�pertoire � initialiser              */
/* intialise le nombre d'�l�ments � z�ro, charge le fichier et le trie          */
/********************************************************************************/

int init_rep(Directory* dir)
{
	/* fonction compl�te : ne pas modifier  */
	selectLang(Fr);

	// Languages DataBase

	// French UI messages
	mess_Fr[0] = "n'existe pas dans le r�pertoire.";
	mess_Fr[1] = "Plus d'autre %s dans le r�pertoire";
	mess_Fr[2] = "Ajout impossible";
	mess_Fr[3] = "Enregistrer modification ? O/N";
	mess_Fr[4] = "Oo";	// Oui
	mess_Fr[6] = "Nn";	// Non
	mess_Fr[7] = "Aa";	// Afficher
	mess_Fr[8] = "Jj";	// Ajouter
	mess_Fr[9] = "Rr";	// Rechercher
	mess_Fr[10] = "Xx";	// Exit
	mess_Fr[11] = "S�lectionnez une option ";
	mess_Fr[12] = "R�pertoire";
	mess_Fr[13] = "(A)fficher tout";
	mess_Fr[14] = "a(J)outer une personne";
	mess_Fr[15] = "recherche(R) une personne";
	mess_Fr[16] = "e(X)it";
	mess_Fr[17] = "Enregistrer sous %s ? O/N";
	mess_Fr[18] = "Nom du fichier: ?";
	mess_Fr[19] = "";
	mess_Fr[20] = "Appuyez sur une touche ..";
	mess_Fr[21] = "Nom : ";
	mess_Fr[22] = "Pr�nom : ";
	mess_Fr[23] = "Le nom est vide ..";
	mess_Fr[24] = "Le nom a �t� tronqu� ..";
	mess_Fr[25] = "Le pr�nom est vide ..";
	mess_Fr[26] = "Le pr�nom a �t� tronqu� ..";
	mess_Fr[27] = "Num�ro de t�l�phone :";
	mess_Fr[28] = "Le num�ro de t�l�phone est vide.";
	mess_Fr[29] = "Le num�ro de t�l�phone a �t� tronqu� ..";
	mess_Fr[30] = "(L)angue";
	mess_Fr[31] = "Ll"; // Langue
	mess_Fr[32] = "(F)ran�ais (E)nglish"; // Langue
	mess_Fr[33] = "Ff"; // Language french
	mess_Fr[34] = "Ee"; // Language english
	mess_Fr[35] = "R�pertoire vide ..";
	mess_Fr[36] = "Recherche";
	mess_Fr[37] = "par (N)om";
	mess_Fr[38] = "par (T)el";
	mess_Fr[39] = "e(X)it";
	mess_Fr[40] = "Nn";
	mess_Fr[41] = "Tt";
	mess_Fr[42] = "Xx";
	mess_Fr[43] = "Espace";
	mess_Fr[44] = "(S)uppression";
	mess_Fr[45] = "Ss";
	mess_Fr[46] = " ";
	mess_Fr[47] = "Entr�e";
	mess_Fr[48] = "\xD"; // Enter Key

	// English UI Messages

	mess_En[0] = "doesn't exist in directory.";
	mess_En[1] = "No more %s in the directory";
	mess_En[2] = "Appending failed";
	mess_En[3] = "Save modifications ?";
	mess_En[4] = "Yy";	// Oui
	mess_En[6] = "Nn";	// Non
	mess_En[7] = "Dd";	// Afficher
	mess_En[8] = "Aa";	// Ajouter
	mess_En[9] = "Ff";	// Rechercher
	mess_En[10] = "Xx";	// Exit
	mess_En[11] = "Select option";
	mess_En[12] = "Contacts Directory";
	mess_En[13] = "(D)isplay all";
	mess_En[14] = "(A)dd contact";
	mess_En[15] = "(F)ind contact";
	mess_En[16] = "e(X)it";
	mess_En[17] = "Save as %s ? Y/N";
	mess_En[18] = "New file name: ?";
	mess_En[19] = "";
	mess_En[20] = "Press any key ..";
	mess_En[21] = "Name : ";
	mess_En[22] = "Firstname : ";
	mess_En[23] = "Name is empty ..";
	mess_En[24] = "Name has been truncated ..";
	mess_En[25] = "Firstname is empty ..";
	mess_En[26] = "Firstname has been truncated ..";
	mess_En[27] = "Phone number : ";
	mess_En[28] = "Phone number is empty..";
	mess_En[29] = "Phone number has been truncated ..";
	mess_En[30] = "(L)anguage";
	mess_En[31] = "Ll"; // Langue
	mess_En[32] = "(F)ran�ais (E)nglish"; // Langue
	mess_En[33] = "Ff"; // Language french
	mess_En[34] = "Ee"; // Language english
	mess_En[35] = "Empty Directory ..";
	mess_En[36] = "Search :";
	mess_En[37] = "by (N)ame";
	mess_En[38] = "by (P)hone Number";
	mess_En[39] = "e(X)it";
	mess_En[40] = "Nn";
	mess_En[41] = "Pp";
	mess_En[42] = "Xx";
	mess_En[43] = "SpaceBar";
	mess_En[44] = "(D)elete";
	mess_En[45] = "Dd";
	mess_En[46] = " ";
	mess_En[47] = "Enter";
	mess_En[48] = "\xD"; // Enter Key


	int errno;
	void* tmpPtr;
	dir->elts_count = 0;
	/* un r�pertoire vide est consid�r� comme d�j� tri� */
	dir->sorted = true; 


#ifdef IMPL_TAB


	tmpPtr = (void*)malloc(MAX_RECORDS * sizeof(Record));
	if (tmpPtr != NULL) {
		dir->tab = (Record*)tmpPtr;
	}
	else return(-1);
#else
#ifdef IMPL_LIST

	tmpPtr = (LinkedList*)NewLinkedList();
	if (tmpPtr != NULL) {
		dir->list = (LinkedList*)tmpPtr;
	}
	else return(-1);
#endif
#endif
	errno = charger(dir, nom_fichier);

	if ((errno == OK) && (dir->elts_count > 0))
	{
		dir->sorted = false;
		trier(dir);
	}
	return(0);
}


/// <summary>
/// Switch exe to selected language
/// </summary>
/// <param name="lang"></param>
void selectLang(LANG lang) {
	currentLanguage = lang;
	switch (currentLanguage)
	{
	case En:
		mess = mess_En;
		break;
	case Fr:
		mess = mess_Fr;
		break;
	default:
		mess = mess_Fr;
		break;
	}
	return;
}
/// <summary>
/// Select language Menu option
/// </summary>
void select_lang() {
	int tabOptions[2] = { 33,34 };
	int selectAction = selectChoice(mess[32], 2, tabOptions);

		switch (selectAction)
		{
		case 34:
			selectLang(En);
			break;
		case 33:
			selectLang(Fr);
			break;
		default:
			selectLang(Fr);
			break;
		}
	return;
}

/// <summary>
/// Read user input from keyboard
/// </summary>
/// <param name="c">: the string</param>
/// <param name="max">: max char count to be read</param>
/// <returns>: string length or -1 when failure</returns>
int saisie_chaine(unsigned char *c, int max)
{
	/* fonction compl�te : ne pas modifier */

	/* longueur de la cha�ne c */
	int l;

	/* saisie en rangeant dans tableau c */
	if (fgets((char *)c, max, stdin) == NULL)          /* lecture des caract�res sur entr�e standard= clavier */
		return -1;
	/* s'il y a une erreur, on renvoie -1                  */

	l = (int)strlen((const char*)c);							   /* calcul de la longueur de la chaine */

	if (c[l - 1] == '\n')					   /* suppression du retour chariot            */
	{									       /* en fin de cha�ne s'il est pr�sent        */
		c[l - 1] = '\0';                       /* �criture d'un caract�re de fin de chaine */
		l--;                                   /* � la place                               */
	}
	return l;								   /* on retourne la longueur de */
} 


/// <summary>
/// Manage User Input of a Contact Datas
/// </summary>
/// <param name="enr">: keyboard Inputs are stored in enr</param>
/// <returns>OK or ERROR</returns>
int saisie_enreg(Record* enr)
{
	unsigned char tmp[MAX_INPUT_CHAR];
	int l;

	printStatusLine(mess[21], consoleSize);
	if ((l = saisie_chaine(tmp, MAX_INPUT_CHAR)) < 0)
		return ERROR;
	/* chaine vide ? */
	if (l == 0)
	{
		printStatusLine(mess[23], consoleSize);
		Sleep(2000);
		return ERROR;
	}
	/* chaine trop longue ? */
	if (l >= MAX_LASTNAME)
	{
		printStatusLine(mess[24], consoleSize);
		Sleep(2000);
	}
	/* on copie dans le champ nom... */
	strncpy_s((char*)enr->nom, _countof(enr->nom), (const char*)tmp, _TRUNCATE);

	/* Entr�e clavier du pr�nom */
	printStatusLine(mess[22], consoleSize);
	if ((l = saisie_chaine(tmp, MAX_INPUT_CHAR)) < 0)
		return ERROR;


	if (l == 0) 	/* pr�nom vide */
	{
		printStatusLine(mess[25], consoleSize);
		Sleep(2000);
	}
	else if (l >= MAX_FIRSTNAME) 	/* pr�nom trop long */
	{
		printStatusLine(mess[26], consoleSize);
		Sleep(2000);

	}
	/* on copie dans le champ prenom... */
	strncpy_s((char*)enr->prenom, _countof(enr->prenom) - 1, (const char*)tmp, _TRUNCATE);

	/* Entr�e clavier du num�ro de t�l�phone */

	printStatusLine(mess[27], consoleSize);
	if ((l = saisie_chaine(tmp, MAX_INPUT_CHAR)) < 0)
		return ERROR;

	if (l == 0) 	/* no tel vide ? */
	{
		printStatusLine(mess[28], consoleSize);
		Sleep(2000);

	} else 	if (l >= MAX_TEL) 	/* no tel trop long */
	{
		printStatusLine(mess[29], consoleSize);
		Sleep(2000);
	}
	/* on copie dans le champ tel... */
	strncpy_s((char*)enr->tel, _countof(enr->tel), (const char*)tmp, _TRUNCATE);

	return OK;
}


/// <summary>
/// Display contact directory page by page
/// </summary>
/// <param name="rep"> : Ref to Contact Directory</param>
void affichage_repertoire(Directory* rep)
{
	int idx = 0;						// Index on current record.
	int cpt = LINES_PER_PAGE;			// Number of displayed lines.
	int selectAction = 0;				// User choice for display control.

	trier(rep);							// Sort directory before display.

	enterAlternateBuffer();				// Display on alternate console buffer.

	printf(CSI "104;93m");				// Select color : bright yellow on bright blue.
	clearScreen();
	//Enter/SpaceBar/eXit
	char buffer[256];
	sprintf_s(buffer, _countof(buffer), "%s/%s/%s", mess[47], mess[43], mess[39]);
	printStatusLine(buffer, consoleSize);

	// Define alternate display buffer layout.
 	int topMargin = (consoleSize.Y - LINES_PER_PAGE ) /2 -2;
	int bottomMargin = consoleSize.Y - LINES_PER_PAGE - topMargin -2;
	int iNumTabStops = 4; // Number of tabulation positions in posTab array 
	int posTab[4] = { 1, MAX_LASTNAME +2,MAX_LASTNAME + MAX_FIRSTNAME+ 4, consoleSize.X };
	bool dispCol[4] = { true, true, true, true };
	drawColumnedFrame(iNumTabStops, posTab, dispCol, topMargin, bottomMargin);


	printf(CSI "%d;1H", topMargin+2); // goto next writing position : upper left corner of the frame

#ifdef IMPL_LIST
	// on place un pointeur sur la t�te de liste,
	// elle est peut-�tre vide
 	SingleLinkedListElem* currentElement = rep->list->head;
#endif
	// While there are some elements to display and user doesn't ask to exit
	while ((idx < rep->elts_count) && (selectAction != 42))
	{
		if (cpt > 0)	// if it remains some elements to display in the page
		{								
#ifdef IMPL_TAB
			affichage_enreg_frmt(rep->tab[idx]);		// Display current element.

#else
#ifdef IMPL_LIST
			affichage_enreg_frmt(currentElement->pers);	// Display current element.
			currentElement = currentElement->next;		// Goto next element.
#endif
#endif

			idx++;										// Goto next element.
			cpt--;										// Decrease line counter.

			// Goto next line start on console.
			if (cpt >= 1 && idx != rep->elts_count) {
				printf("\n\r");
			}
		}
		else
		{	
			// Page is fully displayed, waiting for user interaction.

			int tabOptions[3] = { 48,46,42 }; 	// Enter/SpaceBar/eXit
			selectAction = selectChoice(NULL, 3, tabOptions); 
			// if EnterKey pressed, only one line is displayed
			cpt = (selectAction == 48) ? 1 : LINES_PER_PAGE; 
			if (selectAction != 42) {
				printf("\n\r");
			}
			
		}

	}
	// Press any key
	printStatusLine(mess[20], consoleSize);
	selectAction = _getch();
	printf(CSI "K"); 
	printf(CSI "0m");		// Restore previous writing color.
	exitAlternateBuffer();
}


/// <summary>
/// Find Phone Number with no processing of non-digit chars
/// </summary>
/// <param name="rep"></param>
/// <param name="tel"></param>
/// <param name="ind"></param>
/// <returns></returns>
int rechercher_tel(Directory* rep, unsigned char *tel, int ind)
{
	int i = ind; // indice de d�but de recherche
	int ind_fin;

	char tmp_tel[MAX_TEL];
	char tmp_tel2[MAX_TEL];
	bool trouve = false;

	ind_fin = rep->elts_count - 1; // indice de fin � ne pas d�passer
	strncpy_s(tmp_tel, _countof(tmp_tel), (const char*) tel, _TRUNCATE);
	compact(tmp_tel); // nettoyage du num�ro

#ifdef IMPL_LIST
					  // on se place sur l'�l�ment en i�me position s'il existe
	SingleLinkedListElem* currentElement = GetElementAt(rep->list, i);
	while ((currentElement != NULL) && (!trouve)) {
		strncpy_s((char*)tmp_tel2, _countof(tmp_tel2), (const char*)currentElement->pers.tel, _TRUNCATE);
		compact(tmp_tel2);
		if (strcmp(tmp_tel, tmp_tel2) == 0)
			trouve = true;
		else {
			// si pas trouv�, on passe au suivant
			currentElement = currentElement->next;
			i++;
		}
	}
#else
#ifdef IMPL_TAB
	while ((i <= ind_fin) && (!trouve))
	{

		strncpy_s(tmp_tel2, _countof(tmp_tel2), rep->tab[i].tel, _TRUNCATE);



		compact(tmp_tel2);
		if (strcmp(tmp_tel, tmp_tel2) == 0)
			trouve = true;
		else
			i++;
	}
#endif // IMPL_TAB
#endif

	return((trouve) ? i : -1);
} 


/// <summary>
/// Parse Text Datas in File Lines
/// </summary>
/// <param name="ligne">: pointeur sur un buffer qui contient la ligne lue dans le fichier et termin�e par un z�ro</param>
/// <param name="idx">: pointeur sur un entier qui indique la position courante de la recherche dans la ligne</param>
/// <param name="champ">: pointeur sur la variable � renseigner avec les informations trouv�es entre deux s�parateurs</param>
/// <param name="taille_champ">: la taille du champ � ne pas d�passer</param>
/// <param name="separateur">: le caract�re utilis� comme s�parateur</param>
/// <returns></returns>
int parse_next_field_in_line_char_buffer(unsigned char* ligne, int* idx, unsigned char* champ, int taille_champ,
	char separateur)
{

	int idx2 = 0;

	while ((idx2 < (taille_champ - 2)) && (ligne[*idx] != separateur)
		&& (ligne[*idx] != '\0'))
	{
		champ[idx2] = ligne[*idx];
		idx2 += 1;
		*idx += 1;
	}
	if ((ligne[*idx] == separateur) || (ligne[*idx] == '\0'))
	{
		champ[idx2] = 0;	/* fin de chaine sur caractere suivant */
		return(OK);
	}
	else return(ERROR);		/* fin de ligne ou s�parateur non atteints */

}


/// <summary>
/// Display Find Sub-Menu
/// </summary>
void afficher_menu_recherche()
{
	clearScreen();
	moveCursor(1, consoleSize.Y - 20);
	printf("\n\n %s :\n\n", mess[36]);
	printf("\n\t %s", mess[37]);
	printf("\n\t %s", mess[38]);
	printf("\n\t\t%s\n", mess[39]);

	return;
}

/// <summary>
/// Process Find result with Delete Option or Find Next Option
/// </summary>
/// <param name="rep"></param>
/// <param name="pos"></param>
/// <returns></returns>
bool traiter_recherche(Directory* rep, int pos)
{

	moveCursor(1, consoleSize.Y - 5);

#ifdef IMPL_LIST
	// on r�cup�re l'�l�ment en i�me position
	SingleLinkedListElem* currentElement = GetElementAt(rep->list, pos);
	if (currentElement != NULL) {
		affichage_enreg(currentElement->pers);
	}
#else
#ifdef IMPL_TAB
	affichage_enreg(rep->tab[pos]);
#endif
#endif
	// /espace/(D)elete/e(X)it
	char buffer[256];
	sprintf_s(buffer, _countof(buffer), "%s/%s/%s", mess[43], mess[44], mess[39]);
	printStatusLine(buffer, consoleSize);

	int tabOptions[3] = { 46, 45, 10 }; // Options are linked to text message numbers
	int selectAction = selectChoice(NULL, 3, tabOptions);



	switch (selectAction)
	{
	case 46: // space
		return(true);
		break;
	case 10: // exit
		return(false);
		break;
	case 45: // delete
#ifdef IMPL_TAB
		supprimer_un_contact_dans_rep(rep, pos);
#else
#ifdef IMPL_LIST
		supprimer_un_contact_dans_rep_liste(rep, currentElement);
#endif
#endif
		break;
	}
	return(false);

}


/// <summary>
/// Manage Find Option from Main App Menu
/// </summary>
/// <param name="rep"></param>
void option_rechercher(Directory* rep)
{
	int selectAction;

	int ind;			/* Indice de debut de la recherche ds tableau */
	int pos;			/* Position ds le tableau ou l'element a ete trouve */
	unsigned char nom[MAX_LASTNAME];	/* Les chaines recherchees */
	unsigned char tel[MAX_TEL];
	bool suite = false;			/* true si recherche du suivant, false si on arrete*/
	char tmpBuff[256] = { 0 };
	if (rep->elts_count <= 0)
	{
		// Empty Directory
		printStatusLine(mess[35], consoleSize);
		Sleep(2000);

		return;
	}
	afficher_menu_recherche();
	do
	{

		ind = 0;					// La recherche reprend depuis le debut du tableau
		suite = false;				// Flag poursuite de la recherche */

		int tabOptions[3] = { 40, 41, 42 }; // Options are linked to text message numbers
		selectAction = selectChoice(mess[11], 3, tabOptions);

		switch (selectAction)
		{
		case 40:
			// Ask user for lastname.
			moveCursor(1, consoleSize.Y - 5);
			printf_s("\n%s", mess[21]);
			saisie_chaine(nom, MAX_LASTNAME);

			do
			{
				pos = rechercher_nom(rep, nom, ind);

				if (pos >= 0)
				{
					ind = pos + 1;
					suite = traiter_recherche(rep, pos);
				}
				else
				{
					if (suite == true) {
						// Plus de nouvelle occurence 
						sprintf_s(tmpBuff, sizeof(tmpBuff), mess[1], nom);
						printStatusLine(tmpBuff, consoleSize);
						Sleep(2000);
					}
					else {
						printf_s("\n%s\n", mess[0]);						/* Pas d'occurence trouvee la premiere fois*/
					}
					suite = false;								/* On arrete la recherche */
				}

			} while (suite);
			break;
		case 41:
			// Ask user for phone number
			moveCursor(1, consoleSize.Y - 5);
			printf_s("\n%s", mess[27]);
			saisie_chaine(tel, MAX_TEL);

			do
			{
				pos = rechercher_tel(rep, tel, ind);

				if (pos >= 0)
				{
					ind = pos + 1;
					suite = traiter_recherche(rep, pos);
				}
				else
				{
					if (suite == true) printf(mess[1], tel);	/* Plus de nouvelle occurence */
					else printf(mess[0]);						/* Pas d'occurence trouvee la premiere fois*/
					suite = false;								/* On arrete la recherche */
				}
			} while (suite);
			break;
		}
		afficher_menu_recherche();
	} while (selectAction != 42);

	return;
}


/// <summary>
/// Ask for new contact informations and call function
/// to process the adding in directory contacts data structure
/// </summary>
/// <param name="rep"></param>
void option_ajouter(Directory* rep)
{
	Record tmpenr;
	if (saisie_enreg(&tmpenr))
		if (!ajouter_un_contact_dans_rep(rep, tmpenr))
			printf("\n%s \n", mess[2]);

	return;
}


/// <summary>
/// Ask user for File Pathname
/// </summary>
/// <param name="message"></param>
/// <param name="buffer"></param>
/// <returns></returns>
int saisir_chemin(const char* message, unsigned char* buffer)
{
	printStatusLine(message,consoleSize);
	saisie_chaine(buffer, MAX_FILE_NAME);
	printStatusLine("", consoleSize);
	return(OK);
}

/// <summary>
/// Manage User Option Selection Interaction
/// </summary>
/// <param name="message"></param>
/// <param name="optionsCount"></param>
/// <param name="options"></param>
/// <returns></returns>
int selectChoice(const char* message, int optionsCount, int* options) {
	char buffer[OPTIONBUFFERMAXSIZE] = { 0 };
	char answer;
	int choiceMessageNumber=0;
	for (int i = 0; i < optionsCount && i< OPTIONBUFFERMAXSIZE; i++)
	{
		strcat_s(buffer, _countof(buffer), *(mess + options[i]));
	}
	if (message != NULL) {
		printStatusLine(message, consoleSize);
	}
	answer = readChar((const char * )buffer);
	bool found = false;

	while (choiceMessageNumber < optionsCount && !found ) {
		if (strchr(*(mess+options[choiceMessageNumber]), (int)answer) != NULL) {
			found = true; 
		}
		else {
			choiceMessageNumber++;
		}
	}
	if (!found) { return choiceMessageNumber = -1; }
	
	if (message != NULL) {
		printStatusLine("", consoleSize);
	}

	return options[choiceMessageNumber];
}