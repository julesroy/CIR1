#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include <locale.h>
#include "liste.h"

// #define VERSION 23.0



// cr�e une nouvelle liste chain�e unilat�re vide et renvoie un pointeur sur cette liste
LinkedList *NewLinkedList() {
	LinkedList *tmp;
	tmp = (LinkedList*)malloc(sizeof(LinkedList));
	if (tmp != NULL) {
		tmp->head = NULL;
		tmp->tail = NULL;
		tmp->size = 0;
	}
	return tmp;
}
// cr�e un nouveau maillon qui contient la personne pass�e en param�tre
SingleLinkedListElem  *NewLinkedListElement(Record pers) {
	SingleLinkedListElem *tmp;
	tmp = (SingleLinkedListElem *)malloc(sizeof(SingleLinkedListElem));
	if (tmp != NULL) {	
	tmp->pers = pers;
	tmp->next = NULL;
	}
	return(tmp);
}
// renvoie un pointeur sur l'�l�ment en i�me position dans la liste
SingleLinkedListElem *GetElementAt(LinkedList *Liste, int i) {
	int currentIndex = 0;
	SingleLinkedListElem *element;
	if ((Liste == NULL) || (i < 0) || (i >= Liste->size)) return(NULL);
	if (i == 0) return(Liste->head);
	if (i == Liste->size - 1) return(Liste->tail);
	element = Liste->head;
	while (currentIndex != i  && element != NULL) {
		element = element->next;
		currentIndex++;
	}
	return(element);
}

/// <summary>
/// Add a new Record Value in a Sorted Linked List
/// </summary>
/// <param name="list"> by Ref, Pointer to a Sorted Linked List Structure</param>
/// <param name="pers"> : by Ref, Pointer to a Record Type Value to be inserted at the right place in the Linked List</param>
/// <param name="isGreater"> : by ref , Function Pointer to Comparison Function of two Record type Variables that returns a boolean true Value if a isGreater than b.</param>
/// <returns></returns>
int AddNewElementInSortedList(LinkedList* list, Record* pers, bool (*isGreater)(Record a, Record b)) {
	SingleLinkedListElem* currentElement = NULL;
	SingleLinkedListElem* newElement = NULL;
	SingleLinkedListElem* previousElement = NULL;


	// To compare two records use the isGreater function :
	// ex : if (isGreater(*pers, currentElement->pers) )


	if (list == NULL || pers == NULL || isGreater == NULL) return(0);

	// D�but ajout Code ici
	newElement = NewLinkedListElement(*pers);
	if ((list->head == NULL) || (list->tail == NULL)) { // Si la liste est vide
		list->head = newElement;
		list->tail = newElement;
		(list->size)++;
		return (1);
	}
	else {
		currentElement = list->head;
		while (currentElement != NULL) {
			if (isGreater(*pers, currentElement->pers)) {
				previousElement = currentElement;
				currentElement = currentElement->next;
			}
			else {
				if (previousElement == NULL) { // Si on doit ajouter au d�but de la liste.
					newElement->next = list->head;
					list->head = newElement;
					(list->size)++;
					return (1);
				}

				else { // Cas par d�faut, on ajoute au milieu de la liste.
					newElement->next = currentElement;
					previousElement->next = newElement;
					(list->size)++;
					return (1);
				}
			}
		}
		if (currentElement == NULL) { // Cas o� on doit ajouter � la fin de la liste.
			newElement->next = NULL;
			previousElement->next = newElement;
			list->tail = newElement;
			(list->size)++;
			return (1);
		}
	}
	(list->size)++;
	return(1); // Un �l�ment a �t� ins�r� dans la liste.

	// Fin ajout Code ici
}


/// <summary>
/// Append a Record type value to a Single Linked List.
/// A call to NewLinkedListElement(Record pers) will be performed to create the new element that encapsulates the Record Value.
/// </summary>
/// <param name="list"> by Ref, the Linked List</param>
/// <param name="pers">by Value, the Record Value Type that contents Data for a Contact.</param>
/// <returns>The number of added Record (0 or 1)</returns>
int AppendNewRecordToLinkedList(LinkedList* list, Record pers) {

	// D�but ajout Code ici
	// Cr�e un nouvel �l�ment de liste cha�n�e
	SingleLinkedListElem* new_elem = NewLinkedListElement(pers);
	if (!new_elem) {
		return (0); // �chec de l'allocation de m�moire
	}
	// Si la liste est vide, ajoutez simplement le nouvel �l�ment � la t�te de la liste
	if (list->size == 0) {
		list->head = new_elem;
		list->tail = new_elem;
	}
	// Sinon, ajoutez le nouvel �l�ment � la fin de la liste
	else {
		list->tail->next = new_elem;
		list->tail = new_elem;
	}
	list->size++; // met � jour la taille de la liste
	return (1); // succ�s




	// Fin ajout Code ici
}


int DeleteLinkedListElem(LinkedList* list, SingleLinkedListElem* elem) {
	// D�but ajout Code ici

	int i;
	SingleLinkedListElem* prev = NULL;
	SingleLinkedListElem* current = list->head;

	// Parcours de la liste pour trouver l'�l�ment � supprimer
	while (current != NULL) {
		if (current == elem) {
			// Si l'�l�ment est trouv�, on met � jour les liens de la liste
			if (prev != NULL) {
				prev->next = current->next;
			}
			else {
				list->head = current->next;
			}
			if (current == list->tail) {
				list->tail = prev;
			}
			list->size--;
			free(current);
			return 1; // Un �l�ment a �t� supprim�
		}
		prev = current;
		current = current->next;
	}
	// L'�l�ment recherch� n'a pas �t� trouv�
	return(0);
	// Fin  ajout Code ici
}