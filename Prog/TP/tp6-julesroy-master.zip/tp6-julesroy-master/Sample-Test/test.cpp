#include "gtest/gtest.h"

extern "C" {
#include "../ContactsDirectory/personne.h"
}
extern "C" {
#include "../ContactsDirectory/liste.h"
}
extern "C" {
#include "../ContactsDirectory/directory.h"
}

// Init global test vars
Directory dir;



Record pers1 = { "AAA", "AAA", "111" };
Record pers2 = { "AAA", "BBB", "111" };
Record pers3 = { "BBB", "AAA", "111" };
Record pers4 = { "AAA", "AAA", "222" };
Record pers5 = { "ZZZZ", "ZZZ", "666" };
Record pers6 = { "XXXX", "XXX", "555" };
Record pers7 = { "AA", "AAA", "222" };
Record pers8 = { "ZZZZZ", "ZZZZZ", "999" };

Record getRecord(Directory *dir, int idx) {
#ifdef IMPL_TAB
	return dir->tab[idx];
#else
#ifdef IMPL_LIST
	return GetElementAt(dir->list, idx)->pers;
#endif
#endif
}

// General test

TEST(TestCaseName, TestName) {
  EXPECT_EQ(1, 1);
  EXPECT_TRUE(true);
}

TEST(compact, compact1) {

	char chaine1[] = "A0123456789B";
	compact(chaine1);
	ASSERT_STREQ(chaine1, "0123456789");
}

TEST(estSup, estSup1) {

	ASSERT_FALSE(est_sup(pers1, pers2));
	ASSERT_TRUE(est_sup(pers2, pers1));
	ASSERT_FALSE(est_sup(pers1, pers3));
	ASSERT_TRUE(est_sup(pers3, pers1));
	ASSERT_FALSE(est_sup(pers1, pers4));
}

TEST(AddRecord, AddRecord1) {
	// Init directory code
	int errno;
	void* tmpPtr;
	dir.elts_count = 0;
	dir.sorted = true; /* un r�pertoire vide est tri� :-) */
	modif = false;
#ifdef IMPL_TAB
						  // code pour tableau

	tmpPtr = (void*)malloc(MAX_RECORDS * sizeof(Record));
	if (tmpPtr != NULL) {
		dir.tab = (Record*)tmpPtr;
	}
	else return;
#else
#ifdef IMPL_LIST
						  // code pour Liste
	tmpPtr = (LinkedList*)NewLinkedList();
	if (tmpPtr != NULL) {
		dir.list = (LinkedList*)tmpPtr;
	}
	else return;
#endif
#endif
	int ret = 0;
	ret = ajouter_un_contact_dans_rep(&dir, pers1);
	Record pers = getRecord(&dir, 0);
	ASSERT_EQ(ret, 1);
	ASSERT_EQ(dir.elts_count, 1);
	ASSERT_STREQ((char *)pers.nom, (char*)pers1.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers1.prenom);
	ASSERT_EQ(modif, true);
#ifdef IMPL_TAB
	ASSERT_EQ(dir.sorted, false);
#else
#ifdef IMPL_LIST
	ASSERT_EQ(dir.sorted, true);
#endif
#endif
	ret = ajouter_un_contact_dans_rep(&dir, pers2);
	pers = getRecord(&dir, 1);
	ASSERT_EQ(ret, 1);
	ASSERT_EQ(dir.elts_count, 2);
	ASSERT_STREQ((char*)pers.nom, (char*)pers2.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers2.prenom);
	ASSERT_EQ(modif, true);
#ifdef IMPL_TAB
	ASSERT_EQ(dir.sorted, false);
#else
#ifdef IMPL_LIST
	ASSERT_EQ(dir.sorted, true);
#endif
#endif

	ret = ajouter_un_contact_dans_rep(&dir, pers3);
	pers = getRecord(&dir, 2);
	ASSERT_EQ(ret, 1);
	ASSERT_EQ(dir.elts_count, 3);
	ASSERT_STREQ((char*)pers.nom, (char*)pers3.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers3.prenom);
	ASSERT_EQ(modif, true);
#ifdef IMPL_TAB
	ASSERT_EQ(dir.sorted, false);
#else
#ifdef IMPL_LIST
	ASSERT_EQ(dir.sorted, true);
#endif
#endif

	ret = ajouter_un_contact_dans_rep(&dir, pers4);
	pers = getRecord(&dir, 3);
	ASSERT_EQ(ret, 1);
	ASSERT_EQ(dir.elts_count, 4);
#ifdef IMPL_TAB
	ASSERT_STREQ((char*)pers.nom, (char*)pers4.nom); // "AAA"
	ASSERT_STREQ((char*)pers.prenom, (char*)pers4.prenom);
#else
#ifdef IMPL_LIST
#endif
	ASSERT_STREQ((char*)pers.nom, (char*)pers3.nom); // "BBB"
	ASSERT_STREQ((char*)pers.prenom, (char*)pers3.prenom);
#endif
	ASSERT_EQ(modif, true);
#ifdef IMPL_TAB
	ASSERT_EQ(dir.sorted, false);
#else
#ifdef IMPL_LIST
	ASSERT_EQ(dir.sorted, true);
#endif
#endif
	ret = ajouter_un_contact_dans_rep(&dir, pers5);
	ret = ajouter_un_contact_dans_rep(&dir, pers6);
	ret = ajouter_un_contact_dans_rep(&dir, pers7);
#ifdef IMPL_TAB
	ASSERT_EQ(ret, OK);
#else
#ifdef IMPL_LIST
	ASSERT_EQ(ret, OK);
#endif
#endif
	int nb = 7;
	while (nb <= MAX_RECORDS) {
		ret = ajouter_un_contact_dans_rep(&dir, pers8);
		nb++;
	}
#ifdef IMPL_TAB
	// directory is full
	ASSERT_EQ(ret, ERROR);
	ASSERT_EQ(dir.elts_count, MAX_RECORDS);
#else
#ifdef IMPL_LIST
	ASSERT_EQ(ret, OK);
	ASSERT_EQ(dir.elts_count, MAX_RECORDS+1);
#endif
#endif	

	pers = getRecord(&dir, 6);


#ifdef IMPL_TAB
	ASSERT_STREQ((char*)pers.nom, (char*)pers7.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers7.prenom);
#else
#ifdef IMPL_LIST
	ASSERT_STREQ((char*)pers.nom, (char*)pers5.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers5.prenom);
#endif
#endif


#ifdef IMPL_TAB
	ASSERT_EQ(dir.sorted, false);
#else
#ifdef IMPL_LIST
	ASSERT_EQ(dir.sorted, true);
#endif
#endif



	// deallocate unused ressources
#ifdef IMPL_TAB
	free(dir.tab);
#else

#ifdef IMPL_LIST
	// destroy unused linked list
	SingleLinkedListElem *tmp = dir.list->head;
	SingleLinkedListElem* next = tmp->next;
	while (tmp != NULL)
	{
		next = tmp->next;
		free(tmp);
		tmp = next;
	}
	free(dir.list);
	dir.list = NULL;
	dir.elts_count = 0;
#endif
#endif
}

TEST(DeleteRecord, DeleteRecord1) {
	// Init directory code
	int errno;
	void* tmpPtr;
	dir.elts_count = 0;
	dir.sorted = true; /* un r�pertoire vide est tri� :-) */
	modif = false;
#ifdef IMPL_TAB
	// code pour tableau

	tmpPtr = (void*)malloc(MAX_RECORDS * sizeof(Record));
	if (tmpPtr != NULL) {
		dir.tab = (Record*)tmpPtr;
	}
	else return;
#else
#ifdef IMPL_LIST
	// code pour Liste
	tmpPtr = (LinkedList*)NewLinkedList();
	if (tmpPtr != NULL) {
		dir.list = (LinkedList*)tmpPtr;
	}
	else return;
#endif
#endif
	int ret = 0;
	ret = ajouter_un_contact_dans_rep(&dir, pers1);
	ret = ajouter_un_contact_dans_rep(&dir, pers2);
	ret = ajouter_un_contact_dans_rep(&dir, pers3);
	ret = ajouter_un_contact_dans_rep(&dir, pers4);
	ret = ajouter_un_contact_dans_rep(&dir, pers5);
	ret = ajouter_un_contact_dans_rep(&dir, pers6);
	ret = ajouter_un_contact_dans_rep(&dir, pers7);
	ret = ajouter_un_contact_dans_rep(&dir, pers8);
	Record pers;

#ifdef IMPL_TAB
	supprimer_un_contact_dans_rep(&dir, 0);
	ASSERT_EQ(dir.elts_count, 7);
	pers = getRecord(&dir, 0);
	ASSERT_STREQ((char*)pers.nom, (char*)pers2.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers2.prenom);

	supprimer_un_contact_dans_rep(&dir, 2);
	ASSERT_EQ(dir.elts_count, 6);
	pers = getRecord(&dir, 2);
	ASSERT_STREQ((char*)pers.nom, (char*)pers5.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers5.prenom);

	supprimer_un_contact_dans_rep(&dir, 5);
	ASSERT_EQ(dir.elts_count, 5);
	pers = getRecord(&dir, 4);
	ASSERT_STREQ((char*)pers.nom, (char*)pers7.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers7.prenom);

#else
#ifdef IMPL_LIST


	// expect LinkedList is sorted like this
		//Record pers7 = { "AA", "AAA", "222" };
		//Record pers4 = { "AAA", "AAA", "222" };
		//Record pers1 = { "AAA", "AAA", "111" };
		//Record pers2 = { "AAA", "BBB", "111" };
		//Record pers3 = { "BBB", "AAA", "111" };
		//Record pers6 = { "XXXX", "XXX", "555" };
		//Record pers5 = { "ZZZZ", "ZZZ", "666" };
		//Record pers8 = { "ZZZZZ", "ZZZZZ", "999" };

	ret = supprimer_un_contact_dans_rep_liste(&dir, dir.list->head);
	ASSERT_EQ(ret, OK);
	ASSERT_EQ(dir.elts_count, 7);
	pers = dir.list->head->pers;
	ASSERT_STREQ((char*)pers.nom, (char*)pers1.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers1.prenom);

	ret = supprimer_un_contact_dans_rep_liste(&dir, dir.list->head->next->next);
	ASSERT_EQ(ret, OK);
	ASSERT_EQ(dir.elts_count, 6);
	pers = dir.list->head->next->next->pers;
	ASSERT_STREQ((char*)pers.nom, (char*)pers3.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers3.prenom);
	ASSERT_STREQ((char*)pers.tel, (char*)pers3.tel);


	ret = supprimer_un_contact_dans_rep_liste(&dir, dir.list->tail);
	ASSERT_EQ(ret, OK);
	ASSERT_EQ(dir.elts_count, 5);
	pers = dir.list->tail->pers;

	ASSERT_STREQ((char*)pers.nom, (char*)pers5.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers5.prenom);
	ASSERT_STREQ((char*)pers.tel, (char*)pers5.tel);

#endif
#endif	



	// deallocate unused ressources
#ifdef IMPL_TAB
	free(dir.tab);
#else

#ifdef IMPL_LIST
	// destroy unused linked list
	SingleLinkedListElem* tmp = dir.list->head;
	SingleLinkedListElem* next = tmp->next;
	while (tmp != NULL)
	{
		next = tmp->next;
		free(tmp);
		tmp = next;
	}
	free(dir.list);
	dir.list = NULL;
	dir.elts_count = 0;
#endif
#endif
}

TEST(Sort, Sort1) {

	// Init directory code
	int errno;
	void* tmpPtr;
	dir.elts_count = 0;
	dir.sorted = true; /* un r�pertoire vide est tri� :-) */
	modif = false;

#ifdef IMPL_TAB
	// code pour tableau

	tmpPtr = (void*)malloc(MAX_RECORDS * sizeof(Record));
	if (tmpPtr != NULL) {
		dir.tab = (Record*)tmpPtr;
	}
	else return;
#else
#ifdef IMPL_LIST
	// code pour Liste
	tmpPtr = (LinkedList*)NewLinkedList();
	if (tmpPtr != NULL) {
		dir.list = (LinkedList*)tmpPtr;
	}
	else return;
#endif
#endif

	int ret = 0;
	ret = ajouter_un_contact_dans_rep(&dir, pers1);
	ret = ajouter_un_contact_dans_rep(&dir, pers2);
	ret = ajouter_un_contact_dans_rep(&dir, pers3);
	ret = ajouter_un_contact_dans_rep(&dir, pers4);
	ret = ajouter_un_contact_dans_rep(&dir, pers5);
	ret = ajouter_un_contact_dans_rep(&dir, pers6);
	ret = ajouter_un_contact_dans_rep(&dir, pers7);
	ret = ajouter_un_contact_dans_rep(&dir, pers8);

	// expect array is sorted like this
		//Record pers7 = { "AA", "AAA", "222" };
		//Record pers4 = { "AAA", "AAA", "222" };
		//Record pers1 = { "AAA", "AAA", "111" };
		//Record pers2 = { "AAA", "BBB", "111" };
		//Record pers3 = { "BBB", "AAA", "111" };
		//Record pers6 = { "XXXX", "XXX", "555" };
		//Record pers5 = { "ZZZZ", "ZZZ", "666" };
		//Record pers8 = { "ZZZZZ", "ZZZZZ", "999" };
	trier(&dir);

#ifdef IMPL_TAB
	ret = 0;
	Record pers;

	ASSERT_EQ(dir.elts_count, 8);

	pers = getRecord(&dir, 0);
	ASSERT_STREQ((char*)pers.nom, (char*)pers7.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers7.prenom);

	pers = getRecord(&dir, 1);
	ASSERT_STREQ((char*)pers.nom, (char*)pers4.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers4.prenom);

	pers = getRecord(&dir, 2);
	ASSERT_STREQ((char*)pers.nom, (char*)pers1.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers1.prenom);

	pers = getRecord(&dir, 3);
	ASSERT_STREQ((char*)pers.nom, (char*)pers2.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers2.prenom);
	ASSERT_STREQ((char*)pers.tel, (char*)pers2.tel);

	pers = getRecord(&dir, 4);
	ASSERT_STREQ((char*)pers.nom, (char*)pers3.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers3.prenom);

	pers = getRecord(&dir, 5);
	ASSERT_STREQ((char*)pers.nom, (char*)pers6.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers6.prenom);

	pers = getRecord(&dir, 6);
	ASSERT_STREQ((char*)pers.nom, (char*)pers5.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers5.prenom);

	pers = getRecord(&dir, 7);
	ASSERT_STREQ((char*)pers.nom, (char*)pers8.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers8.prenom);

	ASSERT_EQ(dir.sorted, true);

#else
#ifdef IMPL_LIST
	// Linked lists correct sort order is implicitly checked by add or supp operation
	// because the values are inserted at their correct position at add time.
	// so unitary test for add function may fail due to incorrect value order
	ASSERT_EQ(dir.sorted, true);
#endif
#endif


	// deallocate unused ressources
#ifdef IMPL_TAB
	free(dir.tab);
#else


#ifdef IMPL_LIST
// destroy unused linked list
	SingleLinkedListElem* tmp = dir.list->head;
	SingleLinkedListElem* next = tmp->next;
	while (tmp != NULL)
	{
		next = tmp->next;
		free(tmp);
		tmp = next;
	}
	free(dir.list);
	dir.list = NULL;
	dir.elts_count = 0;
#endif
#endif
}

TEST(Save, Save1) {
	// Init directory code
	int errno;
	void* tmpPtr;
	dir.elts_count = 0;
	dir.sorted = true; /* un r�pertoire vide est tri� :-) */
	modif = false;

#ifdef IMPL_TAB
	// code pour tableau

	tmpPtr = (void*)malloc(MAX_RECORDS * sizeof(Record));
	if (tmpPtr != NULL) {
		dir.tab = (Record*)tmpPtr;
	}
	else return;
#else
#ifdef IMPL_LIST
	// code pour Liste
	tmpPtr = (LinkedList*)NewLinkedList();
	if (tmpPtr != NULL) {
		dir.list = (LinkedList*)tmpPtr;
	}
	else return;
#endif
#endif

	int ret = 0;
	ret = ajouter_un_contact_dans_rep(&dir, pers1);
	ret = ajouter_un_contact_dans_rep(&dir, pers2);
	ret = ajouter_un_contact_dans_rep(&dir, pers3);
	ret = ajouter_un_contact_dans_rep(&dir, pers4);
	ret = ajouter_un_contact_dans_rep(&dir, pers5);
	ret = ajouter_un_contact_dans_rep(&dir, pers6);
	ret = ajouter_un_contact_dans_rep(&dir, pers7);
	ret = ajouter_un_contact_dans_rep(&dir, pers8);

	// expect array is sorted like this
		//Record pers7 = { "AA", "AAA", "222" };
		//Record pers4 = { "AAA", "AAA", "222" };
		//Record pers1 = { "AAA", "AAA", "111" };
		//Record pers2 = { "AAA", "BBB", "111" };
		//Record pers3 = { "BBB", "AAA", "111" };
		//Record pers6 = { "XXXX", "XXX", "555" };
		//Record pers5 = { "ZZZZ", "ZZZ", "666" };
		//Record pers8 = { "ZZZZZ", "ZZZZZ", "999" };


	trier(&dir);
	unsigned char name[] = "test.csv";
	sauvegarder(&dir, name);


#ifdef IMPL_TAB
	dir.elts_count = 0;
	dir.sorted = true; /* un r�pertoire vide est tri� :-) */
	modif = false;

	free(dir.tab);

	tmpPtr = (void*)malloc(MAX_RECORDS * sizeof(Record));
	if (tmpPtr != NULL) {
		dir.tab = (Record*)tmpPtr;
	}
	else return;
#else
#ifdef IMPL_LIST
	// destroy unused linked list
	SingleLinkedListElem* tmp = dir.list->head;
	SingleLinkedListElem* next = tmp->next;
	while (tmp != NULL)
	{
		next = tmp->next;
		free(tmp);
		tmp = next;
}
	free(dir.list);
	dir.list = NULL;
	dir.elts_count = 0;

	// create new list

	tmpPtr = (LinkedList*)NewLinkedList();
	if (tmpPtr != NULL) {
		dir.list = (LinkedList*)tmpPtr;
	}
	else return;
#endif
#endif


	charger(&dir, name);

#ifdef IMPL_TAB
	ret = 0;
	Record pers;

	ASSERT_EQ(dir.elts_count, 8);

	pers = getRecord(&dir, 0);
	ASSERT_STREQ((char*)pers.nom, (char*)pers7.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers7.prenom);

	pers = getRecord(&dir, 1);
	ASSERT_STREQ((char*)pers.nom, (char*)pers4.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers4.prenom);

	pers = getRecord(&dir, 2);
	ASSERT_STREQ((char*)pers.nom, (char*)pers1.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers1.prenom);

	pers = getRecord(&dir, 3);
	ASSERT_STREQ((char*)pers.nom, (char*)pers2.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers2.prenom);

	pers = getRecord(&dir, 4);
	ASSERT_STREQ((char*)pers.nom, (char*)pers3.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers3.prenom);

	pers = getRecord(&dir, 5);
	ASSERT_STREQ((char*)pers.nom, (char*)pers6.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers6.prenom);

	pers = getRecord(&dir, 6);
	ASSERT_STREQ((char*)pers.nom, (char*)pers5.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers5.prenom);

	pers = getRecord(&dir, 7);
	ASSERT_STREQ((char*)pers.nom, (char*)pers8.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers8.prenom);

	ASSERT_EQ(dir.sorted, true);

#else
#ifdef IMPL_LIST
	ret = 0;
	Record pers;
	tmp = dir.list->head;
	//next = tmp->next;


	ASSERT_EQ(dir.elts_count, 8);

	pers = tmp->pers;
	ASSERT_STREQ((char*)pers.nom, (char*)pers7.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers7.prenom);

	tmp = tmp->next;
	pers = tmp->pers;
	ASSERT_STREQ((char*)pers.nom, (char*)pers4.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers4.prenom);

	tmp = tmp->next;
	pers = tmp->pers;

	ASSERT_STREQ((char*)pers.nom, (char*)pers1.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers1.prenom);

	tmp = tmp->next;
	pers = tmp->pers;

	ASSERT_STREQ((char*)pers.nom, (char*)pers2.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers2.prenom);

	tmp = tmp->next;
	pers = tmp->pers;

	ASSERT_STREQ((char*)pers.nom, (char*)pers3.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers3.prenom);

	tmp = tmp->next;
	pers = tmp->pers;

	ASSERT_STREQ((char*)pers.nom, (char*)pers6.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers6.prenom);

	tmp = tmp->next;
	pers = tmp->pers;

	ASSERT_STREQ((char*)pers.nom, (char*)pers5.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers5.prenom);

	tmp = tmp->next;
	pers = tmp->pers;

	ASSERT_STREQ((char*)pers.nom, (char*)pers8.nom);
	ASSERT_STREQ((char*)pers.prenom, (char*)pers8.prenom);

	ASSERT_EQ(dir.sorted, true);
	ASSERT_TRUE(tmp->next==NULL);
#endif
#endif

	// deallocate unused ressources
#ifdef IMPL_TAB
	free(dir.tab);
#else


#ifdef IMPL_LIST
	// destroy unused linked list
	tmp = dir.list->head;
	next = tmp->next;
	while (tmp != NULL)
	{
		next = tmp->next;
		free(tmp);
		tmp = next;
	}
	free(dir.list);
	dir.list = NULL;
	dir.elts_count = 0;
#endif
#endif

}


TEST(Find, Find_name) {
	// Init directory code
	int errno;
	void* tmpPtr;
	dir.elts_count = 0;
	dir.sorted = true; /* un r�pertoire vide est tri� :-) */
	modif = false;

#ifdef IMPL_TAB
	// code pour tableau

	tmpPtr = (void*)malloc(MAX_RECORDS * sizeof(Record));
	if (tmpPtr != NULL) {
		dir.tab = (Record*)tmpPtr;
	}
	else return;
#else
#ifdef IMPL_LIST
	// code pour Liste
	tmpPtr = (LinkedList*)NewLinkedList();
	if (tmpPtr != NULL) {
		dir.list = (LinkedList*)tmpPtr;
	}
	else return;
#endif
#endif

	int ret = 0;
	ret = ajouter_un_contact_dans_rep(&dir, pers1);
	ret = ajouter_un_contact_dans_rep(&dir, pers2);
	ret = ajouter_un_contact_dans_rep(&dir, pers3);
	ret = ajouter_un_contact_dans_rep(&dir, pers4);
	ret = ajouter_un_contact_dans_rep(&dir, pers5);
	ret = ajouter_un_contact_dans_rep(&dir, pers6);
	ret = ajouter_un_contact_dans_rep(&dir, pers7);
	ret = ajouter_un_contact_dans_rep(&dir, pers8);

	trier(&dir);

	int idx = 0;
	ret = rechercher_nom(&dir, (unsigned char *) "XYZ", idx);
	ASSERT_TRUE(ret < 0);
	idx = 0;
	ret = rechercher_nom(&dir, pers1.nom, idx);
	ASSERT_EQ(ret, 1);

	idx=2;
	ret = rechercher_nom(&dir, pers1.nom, idx);
	ASSERT_EQ(ret, 2);
	idx++;
	ret = rechercher_nom(&dir, pers8.nom, idx);
	ASSERT_EQ(ret, 7);

// deallocate unused ressources
#ifdef IMPL_TAB
	free(dir.tab);
#else
#ifdef IMPL_LIST
		// destroy unused linked list
	SingleLinkedListElem* tmp = dir.list->head;
	SingleLinkedListElem* next = tmp->next;
	tmp = dir.list->head;
	next = tmp->next;
	while (tmp != NULL)
	{
		next = tmp->next;
		free(tmp);
		tmp = next;
	}
	free(dir.list);
	dir.list = NULL;
	dir.elts_count = 0;
#endif
#endif
}



