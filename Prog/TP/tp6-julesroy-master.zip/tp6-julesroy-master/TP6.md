# Répertoire de contacts  
(Contacts Directory)  

Il s’agit d’écrire un programme en langage C qui permet d’entrer, de sauvegarder dans un fichier, et de rechercher des contacts dans un répertoire. Le squelette du programme est fourni. Les fichiers **directory.h**, **directory.c** sont complets et ne doivent pas être modifiées. Le squelette peut-être compilé et afficher des contacts pré-enregistrés.

```ad-info
**ATTENTION** : Un **commit** suivi d'un **push** doit être effectué en début de séance **ET** un deuxième commit/push avant de quitter la séance. Le TP sera évalué à partir du travail remis à la **fin de la dernière séance** sur **le dépôt GitHub que vous avez cloné.**

Un commentaire en début de fichier précise votre **nom et votre prénom**.
```


Vous allez fabriquer deux modes de fonctionnement pour ce programme. L'un utilise un **tableau**, l'autre une **liste chaînée** pour stocker les contacts.

Le fichier **directory.h** contient une directive qui permet de choisir le mode de fonctionnement du programme :

```c
#define IMPL_TAB  // Si défini, on compile pour une implémentation tableau du répertoire.

// #define IMPL_LIST // Si défini, on compile pour un implémentation Liste Chaînée du répertoire.
```

Dans un premier temps, vous devez mettre au point la version **tableau**. La version **liste chaînée** pourra être réalisée ensuite.

Seules certaines fonctions du fichier **dirtools.c** doivent alors être complétées. Le code est à compléter aux endroits indiqués.

La version finale du projet comportera les **deux implémentations**, **tableau et liste chaînée**. Les fichiers **dirtools.c** et **liste.c** seront être alors complétés.

La solution comporte également un projet Sample-Test basé sur les **tests unitaires de Google**.  Lorsque le code sera finalisé, l'ensemble des tests mis en place dans le projet de test passeront au vert.

Les informations à prendre en compte pour chaque contact sont le nom, le prénom et un numéro de téléphone.

Les contacts sont sauvegardés dans un fichier au format texte dans le même répertoire que le programme et nommé **data.csv**. Les lignes du fichier sont au format : 

**nom;prénom;0320304050**

L’application **ContactsDirectory** peut être appelée avec un paramètre qui précise un nom différent pour le fichier de données **data.csv**.

Exemple :  ContactsDirectory perso.csv

Le projet intègre les fichiers **liste.h** et **liste.c**  qui fournissent les fonctions nécessaires à la manipulations d'une **liste chaînée unilatère** dans laquelle les enregistrements seront toujours triés puisqu’insérés systématiquement à la bonne position dans la liste.


# Réalisation du TP :

Le projet Visual Studio est constitué d’un fichier principal d**irectory.c** qui comporte la fonction main(), un fichier source **dirtools.c** qui contient des fonctions utilisées par le programme principal et les fonctions à compléter ainsi qu'un fichier d'entêtes **directory.h**

Pour commencer, il faut étudier la fonction **init_rep()** qui initialise entre autres la structure de stockage de donnée. Pour l'implémentation tableau, c'est elle qui alloue le tableau et qui fait appel à la fonction charger pour remplir le tableau avec les données contenues dans le fichier.

La suite logique sera donc de compléter la fonction d'ajout d'un contact dans ce tableau. 

Le nom des fonctions proposées, les définitions globales NE DOIVENT PAS ETRE MODIFIES. Et, vous ne devez pas créer de nouvelles fonctions ni de nouvelles varaiables globales.

La mise en place d'une liste chaînée nécessite également de compléter le fichier **liste.c** pour l’ajout, la lecture et la suppression d'un élément dans une liste.

Le fichier d'entêtes **directory.h** permet de choisir une implémentation tableau ou une implémentation liste chaînée à l’aide des \#define IMPL_TAB ou \#define IMPL_LIST. Il faut mettre en commentaire l'option que vous ne souhaitez pas conserver.

La manipulation des fichiers se fera avec les fonctions suivantes du langage C :


```ad-note
title: Fichiers
* FILE *fic_rep : déclaration d'une variable de type fichier.
* err = fopen_s(&Fic_rep, char * nom_fichier, "w") : ouverture d'un fichier en écriture-remplacement.
[fopen_s, _wfopen_s | Microsoft Learn](https://learn.microsoft.com/fr-fr/cpp/c-runtime-library/reference/fopen-s-wfopen-s?view=msvc-170&viewFallbackFrom=vs-2017)

* fclose(FILE *fic_rep) : fermeture du fichier.

* fgets(char * buffer, long_max_rec, FILE * fic_rep) : lecture d'une ligne dans le fichier.
* feof(fic_rep) : renvoie VRAI si la fin de fichier est atteinte.
* fputs(char * buffer,int fic_rep) : écriture d'une ligne dans le fichier.
```


L'écriture formatée de chaînes de caractères dans un buffer peut se faire à l'aide de la fonction sprintf_s().

**REMARQUE** : Les opérations de lectures et écritures sont réalisées en une seule fois au lancement et en sortie de programme par les fonctions **charger()** et **sauvegarder()**. Toutes les autres opérations sont réalisées en mémoire, soit sur le tableau, soit sur la liste chaînée.

Si vous utilisez des noms de contact comportant des caractères accentués, il faut lancer votre exécutable dans une console CMD.exe après avoir passé la commande **CHCP 1252** ou vérifier que cette commande soit passée par un appel système dans le programme C.

